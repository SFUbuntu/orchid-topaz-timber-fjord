# VECTOR FANG — source dump

Original-IP vertical shmup (canvas 2D, 360×640). Pilots: Rin Kaze / Azure Vesper, Mack Hale / Crimson Talon, Greta Voss / Iron Anvil. NEXO contract. Crew: Vale / Nash.

This zip is the full app source **without** `node_modules` (run `npm install`) and without QA screenshots.

## Run locally

```bash
npm install
npm run dev
```

The Vite scripts bind host `0.0.0.0` port `8080`. Open that in a browser. Production build: `npm run build`.

Auth and database are **off** — scores live in `localStorage`.

## Game code (start here)

| File | What it is |
|---|---|
| `src/game/engine.ts` | Loop, ships, enemies, items, catapult launch, HUD draw, HACKMODE |
| `src/game/world.ts` | Tile map, biomes, carrier stamp, land/water spawn rules |
| `src/game/terrain.ts` | SNES trees, shores, ground props |
| `src/game/collide.ts` | Hit tests |
| `src/game/audio.ts` | WebAudio SFX + title/stage loops |
| `src/game/story.ts` | Briefs, pilots, shop copy, endings |
| `src/game/hiscore.ts` | Cabinet scores |
| `src/components/VectorFang.tsx` | Title, hangar, shop, HUD overlay, how-to |
| `src/styles.css` | Tokens (`vf-*`), Orbitron + Share Tech Mono |
| `src/routes/index.tsx` | Mounts the game |

## Launch clock (sortie 01)

`LAUNCH.lock 0.55` → `beat 0.48` × 3 (3-2-1) → `ignite 0.55` → `shot 2.05` → `lift 0.80`. Total `LAUNCH_DUR` 5.39s. T-minus to the shot is 2.54s.

## Items / scoring

- R red cube +1 power, Q blue +2, surplus 5000
- L / S missile chips, surplus 5000
- B bomb (max 7), surplus 5000
- P max gun+drones, surplus 10000
- M medal 500 + stage count
- N NIX 3000
- F LUMA (hold 1; dumps pods on death)
- Stage bonus: `max(1,medals) × max(1,bombs) × 1000`

## Assets

Sprites, portraits, tiles, shop icons: `public/sprites/`. Title flyer and UI stills: `public/ui/`, `public/og.jpg`.

## Not in this zip

- `node_modules/` — install from `package.json`
- QA `screenshots/`
- Generated `.vercel` / `.tanstack` caches
