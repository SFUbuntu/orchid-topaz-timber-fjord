VECTOR FANG — offline copy
==========================

This folder is the full game: code, sprites, portraits, shop icons,
stage UI photos, and the original sprite sheets you uploaded.

This is a browser game (not a Windows .exe / Mac .app). After a one-time
setup it runs on your computer with no internet.

WHAT YOU NEED
-------------
Node.js 22 or newer, from https://nodejs.org
(the LTS installer is fine — Next / Install / Finish)

HOW TO RUN
----------
1. Unzip this folder anywhere you like.
2. Open a terminal (macOS: Terminal; Windows: Command Prompt or PowerShell).
3. Go into this folder. Example:

     cd path/to/VECTOR-FANG-offline

4. Install libraries once (needs internet this first time only):

     npm install

5. Start the game:

     npm run dev

6. Open a browser and go to:

     http://localhost:8080

Leave that terminal open while you play. Close it (or press Ctrl+C) to quit.

CONTROLS
--------
  WASD or arrows   move
  Space            gun
  Z                special
  X                bomb
  C                drone
  P                pause

  Title: type HACKMODE for auto-play

ASSETS INCLUDED
---------------
  public/sprites/            ships, bosses, enemies
  public/sprites/portraits/  Rin, Mack, Greta, Vale, Nash
  public/sprites/shop/       hangar kit icons
  public/ui/                 select / shop / briefing / game over art
  public/og.jpg, favicon.svg, x-banner.jpg
  original-art/              the sprite sheets you uploaded

Scores save in the browser (localStorage). No account required.

TROUBLESHOOTING
---------------
- "npm is not recognized" → Node.js is not installed, or open a new terminal
  after installing it.
- Port already in use → close other copies of the game and try again.
- Blank page → make sure you used http://localhost:8080 (not a file:// path).
