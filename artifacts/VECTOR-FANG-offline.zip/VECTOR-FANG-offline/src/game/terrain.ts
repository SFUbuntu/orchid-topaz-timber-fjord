export type DecorKind = "bush" | "tree" | "lake" | "sea" | "rock" | "dune" | "cloud" | "reef" | "grass" | "ruin";
export type TargetKind = "bunker" | "radar" | "hangar" | "silo" | "dock" | "crate" | "tower";

export type Decor = {
  alive: boolean;
  x: number;
  y: number;
  kind: DecorKind;
  s: number;
  flip: number;
  phase: number;
};

export type Ground = {
  alive: boolean;
  x: number;
  y: number;
  kind: TargetKind;
  hp: number;
  maxHp: number;
  r: number;
  score: number;
  flash: number;
  t: number;
};

export type StageTheme = {
  decor: DecorKind[];
  targets: TargetKind[];
  water: "none" | "lake" | "sea";
  woods: boolean;
};

export const STAGE_THEME: StageTheme[] = [
  { decor: ["grass", "bush", "tree", "ruin"], targets: ["hangar", "bunker", "radar", "crate"], water: "none", woods: true },
  { decor: ["cloud", "rock"], targets: ["tower", "radar", "crate"], water: "none", woods: false },
  { decor: ["tree", "bush", "lake", "grass"], targets: ["bunker", "crate", "radar"], water: "lake", woods: true },
  { decor: ["dune", "rock", "lake"], targets: ["bunker", "crate", "tower"], water: "lake", woods: false },
  { decor: ["rock", "dune", "lake"], targets: ["tower", "bunker", "radar"], water: "lake", woods: false },
  { decor: ["rock", "ruin"], targets: ["silo", "bunker", "crate"], water: "none", woods: false },
  { decor: ["cloud"], targets: ["hangar", "radar", "tower"], water: "none", woods: false },
  { decor: ["sea", "reef", "rock"], targets: ["dock", "crate", "bunker"], water: "sea", woods: false },
  { decor: ["ruin", "rock"], targets: ["hangar", "bunker", "tower", "crate"], water: "none", woods: false },
  { decor: ["ruin", "sea", "cloud"], targets: ["tower", "hangar", "bunker", "radar"], water: "sea", woods: false },
];

export function targetSpec(kind: TargetKind): { hp: number; r: number; score: number } {
  if (kind === "crate") return { hp: 4, r: 12, score: 250 };
  if (kind === "radar") return { hp: 10, r: 16, score: 480 };
  if (kind === "bunker") return { hp: 16, r: 18, score: 620 };
  if (kind === "dock") return { hp: 14, r: 20, score: 540 };
  if (kind === "silo") return { hp: 18, r: 16, score: 700 };
  if (kind === "tower") return { hp: 20, r: 14, score: 800 };
  return { hp: 22, r: 22, score: 900 };
}

export function drawDecor(c: CanvasRenderingContext2D, d: Decor, t: number) {
  c.save();
  c.translate(d.x, d.y);
  if (d.flip < 0) c.scale(-1, 1);
  const s = d.s;
  if (d.kind === "bush") {
    c.fillStyle = "#2d6a28";
    c.beginPath();
    c.ellipse(0, 4, 14 * s, 8 * s, 0, 0, Math.PI * 2);
    c.fill();
    c.fillStyle = "#4a9a3a";
    c.beginPath();
    c.ellipse(-6 * s, 0, 8 * s, 7 * s, 0, 0, Math.PI * 2);
    c.ellipse(6 * s, -1, 9 * s, 8 * s, 0, 0, Math.PI * 2);
    c.ellipse(0, -4 * s, 7 * s, 6 * s, 0, 0, Math.PI * 2);
    c.fill();
  } else if (d.kind === "tree") {
    c.fillStyle = "#4a3018";
    c.fillRect(-2.5 * s, 0, 5 * s, 16 * s);
    c.fillStyle = "#1e5a22";
    c.beginPath();
    c.moveTo(0, -22 * s);
    c.lineTo(12 * s, 4 * s);
    c.lineTo(-12 * s, 4 * s);
    c.closePath();
    c.fill();
    c.fillStyle = "#2f7a32";
    c.beginPath();
    c.moveTo(0, -28 * s);
    c.lineTo(9 * s, -4 * s);
    c.lineTo(-9 * s, -4 * s);
    c.closePath();
    c.fill();
  } else if (d.kind === "lake") {
    c.fillStyle = "#1a5a78";
    c.beginPath();
    c.ellipse(0, 0, 28 * s, 14 * s, 0, 0, Math.PI * 2);
    c.fill();
    c.fillStyle = "#3ec8ff";
    c.globalAlpha = 0.35;
    c.beginPath();
    c.ellipse(-4, -2, 16 * s, 6 * s, 0, 0, Math.PI * 2);
    c.fill();
    c.globalAlpha = 1;
    c.strokeStyle = "#7fe8ff";
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(-16 * s, Math.sin(t * 2 + d.phase) * 2);
    c.quadraticCurveTo(0, 4, 16 * s, Math.sin(t * 2 + d.phase + 1) * 2);
    c.stroke();
  } else if (d.kind === "sea") {
    c.fillStyle = "#0a2840";
    c.fillRect(-80 * s, -10 * s, 160 * s, 28 * s);
    c.fillStyle = "#1a5080";
    c.fillRect(-80 * s, -6 * s, 160 * s, 8 * s);
    c.strokeStyle = "#3ec8ff";
    c.globalAlpha = 0.5;
    c.lineWidth = 1.2;
    c.beginPath();
    for (let i = -70; i < 70; i += 18) {
      const y = Math.sin(t * 2.2 + d.phase + i * 0.08) * 3;
      c.moveTo(i * s, y);
      c.quadraticCurveTo((i + 9) * s, y + 4, (i + 18) * s, y);
    }
    c.stroke();
    c.globalAlpha = 1;
  } else if (d.kind === "rock") {
    c.fillStyle = "#5a5348";
    c.beginPath();
    c.moveTo(-12 * s, 8 * s);
    c.lineTo(-6 * s, -8 * s);
    c.lineTo(4 * s, -12 * s);
    c.lineTo(14 * s, 2 * s);
    c.lineTo(8 * s, 10 * s);
    c.closePath();
    c.fill();
    c.fillStyle = "#8a8070";
    c.beginPath();
    c.moveTo(-4 * s, -4 * s);
    c.lineTo(2 * s, -10 * s);
    c.lineTo(6 * s, -2 * s);
    c.closePath();
    c.fill();
  } else if (d.kind === "dune") {
    c.fillStyle = "#c48a32";
    c.beginPath();
    c.ellipse(0, 6, 32 * s, 12 * s, 0, 0, Math.PI * 2);
    c.fill();
    c.fillStyle = "#e0a040";
    c.beginPath();
    c.ellipse(-8 * s, 2, 16 * s, 7 * s, 0, 0, Math.PI * 2);
    c.fill();
  } else if (d.kind === "cloud") {
    c.fillStyle = "#d8e4f0";
    c.globalAlpha = 0.55;
    c.beginPath();
    c.ellipse(0, 0, 22 * s, 9 * s, 0, 0, Math.PI * 2);
    c.ellipse(-12 * s, 2, 12 * s, 7 * s, 0, 0, Math.PI * 2);
    c.ellipse(12 * s, 1, 14 * s, 8 * s, 0, 0, Math.PI * 2);
    c.fill();
    c.globalAlpha = 1;
  } else if (d.kind === "reef") {
    c.fillStyle = "#2a6a5a";
    c.beginPath();
    c.moveTo(-10 * s, 8 * s);
    c.lineTo(-4 * s, -6 * s);
    c.lineTo(2 * s, 4 * s);
    c.lineTo(8 * s, -8 * s);
    c.lineTo(12 * s, 8 * s);
    c.closePath();
    c.fill();
    c.fillStyle = "#3ec8ff";
    c.globalAlpha = 0.4;
    c.fillRect(-16 * s, 6 * s, 32 * s, 6 * s);
    c.globalAlpha = 1;
  } else if (d.kind === "grass") {
    c.strokeStyle = "#4a8a32";
    c.lineWidth = 1.2;
    for (let i = -3; i <= 3; i++) {
      c.beginPath();
      c.moveTo(i * 3 * s, 6);
      c.lineTo(i * 3 * s + Math.sin(t + i) * 2, -6 * s);
      c.stroke();
    }
  } else {
    c.fillStyle = "#3a3a44";
    c.fillRect(-14 * s, -6 * s, 28 * s, 16 * s);
    c.fillStyle = "#1a1a22";
    c.fillRect(-10 * s, -2 * s, 8 * s, 6 * s);
    c.fillRect(2 * s, -2 * s, 8 * s, 6 * s);
  }
  c.restore();
}

export function drawGround(c: CanvasRenderingContext2D, g: Ground) {
  c.save();
  c.translate(g.x, g.y);
  if (g.kind === "crate") {
    c.fillStyle = "#8a5a22";
    c.fillRect(-10, -10, 20, 20);
    c.strokeStyle = "#f0c14a";
    c.lineWidth = 1.4;
    c.strokeRect(-10, -10, 20, 20);
    c.beginPath();
    c.moveTo(-10, -10);
    c.lineTo(10, 10);
    c.moveTo(10, -10);
    c.lineTo(-10, 10);
    c.stroke();
  } else if (g.kind === "radar") {
    c.fillStyle = "#4a5568";
    c.fillRect(-5, 0, 10, 16);
    c.strokeStyle = "#cfd8e6";
    c.lineWidth = 2;
    c.beginPath();
    c.arc(0, -4, 12, Math.PI * 0.15, Math.PI * 0.85);
    c.stroke();
    c.fillStyle = "#3ec8ff";
    c.beginPath();
    c.arc(0, -4, 4, 0, Math.PI * 2);
    c.fill();
  } else if (g.kind === "bunker") {
    c.fillStyle = "#4a5a38";
    c.fillRect(-16, -6, 32, 18);
    c.fillStyle = "#2a3a20";
    c.fillRect(-18, 8, 36, 6);
    c.fillStyle = "#070b14";
    c.fillRect(-8, -2, 6, 5);
    c.fillRect(4, -2, 6, 5);
    c.fillStyle = "#7cb86a";
    c.fillRect(-16, -10, 32, 4);
  } else if (g.kind === "hangar") {
    c.fillStyle = "#5a6478";
    c.beginPath();
    c.moveTo(-22, 12);
    c.lineTo(-22, -4);
    c.lineTo(0, -16);
    c.lineTo(22, -4);
    c.lineTo(22, 12);
    c.closePath();
    c.fill();
    c.fillStyle = "#1a2030";
    c.fillRect(-10, 0, 20, 12);
    c.fillStyle = "#f0c14a";
    c.fillRect(-22, -4, 44, 2);
  } else if (g.kind === "silo") {
    c.fillStyle = "#6a6048";
    c.beginPath();
    c.ellipse(0, 10, 12, 5, 0, 0, Math.PI * 2);
    c.fill();
    c.fillRect(-12, -10, 24, 20);
    c.fillStyle = "#c4d46a";
    c.beginPath();
    c.ellipse(0, -10, 12, 5, 0, 0, Math.PI * 2);
    c.fill();
    c.fillStyle = "#070b14";
    c.fillRect(-3, -6, 6, 10);
  } else if (g.kind === "dock") {
    c.fillStyle = "#6a4a22";
    c.fillRect(-22, 0, 44, 10);
    c.fillStyle = "#3ec8ff";
    c.globalAlpha = 0.35;
    c.fillRect(-24, 8, 48, 8);
    c.globalAlpha = 1;
    c.fillStyle = "#8a6a3a";
    c.fillRect(-20, -8, 8, 10);
    c.fillRect(12, -8, 8, 10);
  } else {
    c.fillStyle = "#6a7080";
    c.fillRect(-8, -18, 16, 32);
    c.fillStyle = "#3ec8ff";
    c.fillRect(-6, -14, 4, 4);
    c.fillRect(2, -14, 4, 4);
    c.fillRect(-6, -6, 4, 4);
    c.fillRect(2, -6, 4, 4);
    c.fillStyle = "#ff3b4a";
    c.fillRect(-2, -22, 4, 6);
  }
  if (g.flash > 0) {
    c.globalAlpha = Math.min(0.8, g.flash * 8);
    c.fillStyle = "#fff";
    c.beginPath();
    c.arc(0, 0, g.r * 0.8, 0, Math.PI * 2);
    c.fill();
  }
  c.restore();
  c.fillStyle = "#1a1a1a";
  c.fillRect(g.x - 14, g.y - g.r - 8, 28, 3);
  c.fillStyle = "#f0c14a";
  c.fillRect(g.x - 14, g.y - g.r - 8, 28 * (g.hp / g.maxHp), 3);
}
