export class Sfx {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  music: GainNode | null = null;
  sfx: GainNode | null = null;
  muted = false;
  musicTimer = 0;
  stage = 0;
  osc: OscillatorNode | null = null;
  lfo: OscillatorNode | null = null;

  unlock() {
    if (!this.ctx) {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new Ctx({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.music = this.ctx.createGain();
      this.sfx = this.ctx.createGain();
      this.master.gain.value = 0.55;
      this.music.gain.value = 0.12;
      this.sfx.gain.value = 0.28;
      this.music.connect(this.master);
      this.sfx.connect(this.master);
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.55, this.ctx.currentTime, 0.02);
  }

  beep(freq: number, dur = 0.08, type: OscillatorType = "square", vol = 0.4, slide = 0) {
    if (!this.ctx || !this.sfx || this.muted) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(this.sfx);
    o.start(t);
    o.stop(t + dur + 0.02);
    o.onended = () => {
      o.disconnect();
      g.disconnect();
    };
  }

  shot() {
    this.beep(880 + Math.random() * 80, 0.05, "square", 0.12, -400);
  }
  boom() {
    this.beep(120 + Math.random() * 40, 0.28, "sawtooth", 0.35, -80);
  }
  hit() {
    this.beep(320, 0.06, "triangle", 0.18, -200);
  }
  pickup() {
    this.beep(660, 0.08, "square", 0.22, 400);
  }
  bomb() {
    this.beep(80, 0.5, "sawtooth", 0.5, -40);
  }
  overdrive() {
    this.beep(220, 0.2, "square", 0.2, 600);
  }
  die() {
    this.beep(180, 0.45, "sawtooth", 0.4, -150);
  }
  warn() {
    if (!this.ctx || !this.sfx || this.muted) return;
    const t = this.ctx.currentTime;
    const notes = [740, 620, 520];
    for (let i = 0; i < notes.length; i++) {
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = "square";
      o.frequency.value = notes[i];
      const start = t + i * 0.22;
      g.gain.setValueAtTime(0.0001, start);
      g.gain.exponentialRampToValueAtTime(0.28, start + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, start + 0.2);
      o.connect(g);
      g.connect(this.sfx);
      o.start(start);
      o.stop(start + 0.22);
    }
  }
  boss() {
    this.beep(55, 0.7, "sawtooth", 0.48, 30);
  }
  phase() {
    this.beep(160, 0.32, "sawtooth", 0.38, 280);
  }
  tell() {
    this.beep(980, 0.09, "square", 0.16, 220);
  }

  startMusic(stage: number) {
    this.stage = stage;
    this.unlock();
    this.stopMusic();
    if (!this.ctx || !this.music) return;
    const o = this.ctx.createOscillator();
    const l = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    const f = this.ctx.createBiquadFilter();
    o.type = "sawtooth";
    l.type = "sine";
    const base = [110, 98, 123, 92, 82, 73, 130, 87, 104, 69][stage % 10];
    o.frequency.value = base;
    l.frequency.value = 0.25 + stage * 0.05;
    const lg = this.ctx.createGain();
    lg.gain.value = 18;
    l.connect(lg);
    lg.connect(o.frequency);
    f.type = "lowpass";
    f.frequency.value = 420 + stage * 80;
    g.gain.value = 0.35;
    o.connect(f);
    f.connect(g);
    g.connect(this.music);
    o.start();
    l.start();
    this.osc = o;
    this.lfo = l;
  }

  stopMusic() {
    try {
      this.osc?.stop();
      this.lfo?.stop();
    } catch {
      /* already stopped */
    }
    this.osc?.disconnect();
    this.lfo?.disconnect();
    this.osc = null;
    this.lfo = null;
  }
}
