import { Sfx } from "./audio";
import { BUYOUT, bountyOf, emptyLoadout, emptyAmmo, shopPrice, SHOP, ammoMul, canEquip, specialCap, specialCount, DIFFS, type CrewMode, type DiffId, type Ending, type Loadout, type ShipId, type ShopId } from "./story";
import { ALPHA, continueCost, insertScore, loadTable, qualifies, type HiEntry } from "./hiscore";
import { STAGE_THEME, drawDecor, drawGround, targetSpec, type Decor, type Ground, type TargetKind } from "./terrain";

export const GW = 360;
export const GH = 640;
const HS_KEY = "vectorfang-hs-v1";

export type Kind =
  | "wasp"
  | "hornet"
  | "gunbarge"
  | "gilded"
  | "eyepod"
  | "redtide"
  | "lancejet"
  | "keel"
  | "strider"
  | "aegis"
  | "core"
  | "mine"
  | "spinner"
  | "gyre"
  | "redmaw"
  | "solarmoth"
  | "harborking"
  | "crowncore"
  | "siegecrawler"
  | "phantomwing"
  | "rootcitadel"
  | "dunehauler"
  | "skypike"
  | "silohydra"
  | "ironalbatross"
  | "krakenkeel"
  | "battlekeel"
  | "arsenalgate"
  | "skycathedral";

type Mode = "lance" | "seek";
export type Screen = "title" | "select" | "how" | "story" | "roster" | "brief" | "shop" | "play" | "pause" | "over" | "win" | "clear" | "continue" | "name" | "vsresult" | "intro" | "thanks" | "ending";
export type ClearLine = { name: string; ammo: number; refund: number };
export type ClearReport = {
  stage: number;
  last: boolean;
  score: number;
  hi: number;
  bounty: number;
  refund: number;
  lives: number;
  power: number;
  bombs: number;
  armor: number;
  specials: ClearLine[];
  kits: { name: string; owned: number }[];
};

type Ent = {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  maxHp: number;
  kind: Kind;
  t: number;
  score: number;
  ground: boolean;
  phase: number;
  flash: number;
  tag: number;
  tell: number;
  atk: number;
};

type Bullet = { alive: boolean; x: number; y: number; vx: number; vy: number; r: number; dmg: number; homing: boolean; friendly: boolean; color: string; pierce: boolean; hit: Ent[]; vsGround: boolean; cpu: boolean; ay: number; spin: number; wait: number; split: number };
type Item = { alive: boolean; x: number; y: number; vy: number; type: "P" | "L" | "S" | "B" | "G" | "Q" | "W" | "M" | "1" | "H" };
type Spark = { alive: boolean; x: number; y: number; vx: number; vy: number; life: number; color: string; s: number };
type Drone = { x: number; y: number; ang: number };

export const STAGES = [
  "FORWARD BASE",
  "STORM FRONT",
  "GREEN MAW",
  "GLASS DUNES",
  "RAZOR CANYON",
  "HOLLOW VEIN",
  "CLOUD DECK",
  "BLACK TIDE",
  "STEEL YARD",
  "THUNDERKEEP",
];

type BossSpec = { kind: Kind; name: string; hp: number; r: number; score: number; restY: number; weak: string };

export const BOSS_META: BossSpec[] = [
  { kind: "siegecrawler", name: "SIEGE CRAWLER", hp: 125, r: 34, score: 3500, restY: 102, weak: "Radar mast — hit the dish from above." },
  { kind: "phantomwing", name: "PHANTOM WING", hp: 145, r: 36, score: 4200, restY: 84, weak: "It only silhouettes when it fires." },
  { kind: "rootcitadel", name: "ROOT CITADEL", hp: 160, r: 40, score: 5000, restY: 90, weak: "Generator vents on the roof." },
  { kind: "dunehauler", name: "DUNE HAULER", hp: 175, r: 40, score: 5500, restY: 98, weak: "Cut the treads. Deck guns lose their angle." },
  { kind: "skypike", name: "SKY PIKE", hp: 190, r: 36, score: 6200, restY: 86, weak: "Belly bay opens on the dive." },
  { kind: "silohydra", name: "SILO HYDRA", hp: 210, r: 38, score: 7000, restY: 96, weak: "Close the lids in order." },
  { kind: "ironalbatross", name: "IRON ALBATROSS", hp: 230, r: 44, score: 8000, restY: 88, weak: "Inboard engines. Two dead and it drops." },
  { kind: "battlekeel", name: "BATTLEKEEL", hp: 255, r: 44, score: 9000, restY: 102, weak: "Magazine hatches amidships." },
  { kind: "arsenalgate", name: "ARSENAL GATE", hp: 280, r: 38, score: 10000, restY: 88, weak: "Hinge guns. Knock them or the gate closes." },
  { kind: "skycathedral", name: "SKY CATHEDRAL", hp: 360, r: 48, score: 16000, restY: 108, weak: "Gap in the rotating shield, then the core." },
];

const SUB_BOSS: BossSpec = { kind: "krakenkeel", name: "KRAKEN KEEL", hp: 115, r: 32, score: 4000, restY: 112, weak: "The snorkel. Then the magazine." };

const BOSS_KINDS = new Set<Kind>([...BOSS_META.map((b) => b.kind), SUB_BOSS.kind]);

export function isBossKind(k: Kind) {
  return BOSS_KINDS.has(k);
}

const SPRITE_SRC: Record<string, string> = {
  azure: "/sprites/azure.png",
  crimson: "/sprites/crimson.png",
  iron: "/sprites/iron.png",
  wasp: "/sprites/wasp.png",
  hornet: "/sprites/hornet.png",
  gunbarge: "/sprites/gunbarge.png",
  gilded: "/sprites/gilded.png",
  eyepod: "/sprites/eyepod.png",
  redtide: "/sprites/redtide.png",
  gyre: "/sprites/gyre.png",
  redmaw: "/sprites/redmaw.png",
  solarmoth: "/sprites/solarmoth.png",
  harborking: "/sprites/harborking.png",
  crowncore: "/sprites/crowncore.png",
  siegcrawler: "/sprites/siegecrawler.png",
  phantomwing: "/sprites/phantomwing.png",
  rootcitadel: "/sprites/rootcitadel.png",
  dunehauler: "/sprites/redmaw.png",
  skypike: "/sprites/skypike.png",
  silohydra: "/sprites/silohydra.png",
  ironalbatross: "/sprites/ironalbatross.png",
  krakenkeel: "/sprites/krakenkeel.png",
  battlekeel: "/sprites/harborking.png",
  arsenalgate: "/sprites/gyre.png",
  skycathedral: "/sprites/crowncore.png",
};

export class VectorFangGame {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  sfx = new Sfx();
  sprites: Record<string, HTMLImageElement> = {};
  keys = new Set<string>();
  inject = new Set<string>();
  screen: Screen = "title";
  ship: ShipId = "azure";
  score = 0;
  hi = 0;
  lives = 3;
  bombs = 3;
  power = 0;
  dronesN = 1;
  mode: Mode = "lance";
  overdrive = 0;
  invuln = 0;
  shake = 0;
  px = GW / 2;
  py = GH - 80;
  hitR = 4;
  speed = 200;
  fireCd = 0;
  bombCd = 0;
  stage = 0;
  stageT = 0;
  spawnI = 0;
  chain = 1;
  chainT = 0;
  acc = 0;
  last = 0;
  running = false;
  raf = 0;
  enemies: Ent[] = [];
  pBullets: Bullet[] = [];
  eBullets: Bullet[] = [];
  items: Item[] = [];
  sparks: Spark[] = [];
  drones: Drone[] = [{ x: 0, y: 0, ang: 0 }];
  bg = 0;
  muted = false;
  touch = { mx: 0, my: 0, moving: false, fire: false, bomb: false, mode: false, special: false };
  onChange: () => void = () => {};
  stageClearT = 0;
  bossAlive = false;
  bossWarn = false;
  midCleared = false;
  midSpawnT = 0;
  qaSpeed = 0;
  qaYaw = 0;
  modeHeld = false;
  ending: Ending | "none" = "none";
  loadout: Loadout = emptyLoadout();
  ammo: Loadout = emptyAmmo();
  railN = 0;
  armor = 0;
  specialCd = 0;
  clearReport: ClearReport | null = null;
  continues = 0;
  continueT = 0;
  hiTable: HiEntry[] = [];
  nameChars = ["A", "A", "A"];
  nameSlot = 0;
  pendingEnd: Screen = "over";
  diff: DiffId = "normal";
  vs = false;
  demo = false;
  idleT = 0;
  demoT = 0;
  demoPilotI = 0;
  cpuShip: ShipId = "crimson";
  cpuScore = 0;
  cx = GW / 2 + 48;
  cy = GH - 90;
  cpuFireCd = 0;
  crew: CrewMode = "solo";
  p2Ship: ShipId = "crimson";
  hack = false;
  hackBuf = "";
  p2invuln = 0;
  startLives = 3;
  decor: Decor[] = [];
  grounds: Ground[] = [];
  phaseBanner = 0;
  bossAtk = "";

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("No 2D context");
    this.ctx = ctx;
    this.hi = Number(localStorage.getItem(HS_KEY) || 0);
    this.hiTable = loadTable();
    if (this.hiTable[0]) this.hi = Math.max(this.hi, this.hiTable[0].score);
    this.loadSprites();
    this.bind();
  }

  loadSprites() {
    for (const [k, src] of Object.entries(SPRITE_SRC)) {
      const im = new Image();
      im.crossOrigin = "anonymous";
      im.src = src;
      this.sprites[k] = im;
    }
  }

  bind() {
    const onDown = (e: KeyboardEvent) => {
      this.keys.add(e.code);
      if (this.demo) {
        this.abortDemo();
        return;
      }
      if (this.screen === "title") {
        this.idleT = 0;
        const ch = e.key.length === 1 ? e.key.toUpperCase() : "";
        if (/^[A-Z]$/.test(ch)) {
          this.hackBuf = (this.hackBuf + ch).slice(-8);
          if (this.hackBuf === "HACKMODE") {
            this.hackBuf = "";
            this.startHack();
            return;
          }
        } else if (e.code !== "ShiftLeft" && e.code !== "ShiftRight") {
          this.hackBuf = "";
        }
      }
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Enter"].includes(e.code)) e.preventDefault();
      if (e.code === "KeyP" && this.screen === "play" && !this.hack) this.pause();
      if (e.code === "Escape" && this.screen === "play") this.pause();
      if (e.code === "KeyM") this.toggleMute();
      if (this.screen === "continue" && (e.code === "Space" || e.code === "Enter" || e.code === "KeyZ")) this.doContinue();
      if (this.screen === "name") this.handleNameKey(e.code);
      if (this.screen === "intro" && (e.code === "Space" || e.code === "Enter")) this.dismissIntro();
      if (this.screen === "thanks" && (e.code === "Space" || e.code === "Enter")) this.dismissThanks();
    };
    const onUp = (e: KeyboardEvent) => this.keys.delete(e.code);
    window.addEventListener("keydown", onDown);
    window.addEventListener("keyup", onUp);
    window.addEventListener("blur", () => this.keys.clear());
    const onPointer = () => {
      if (this.demo) this.abortDemo();
    };
    this.canvas.addEventListener("pointerdown", onPointer);
    document.addEventListener("visibilitychange", () => {
      this.keys.clear();
      if (document.visibilityState === "visible") this.sfx.unlock();
    });
    (this as unknown as { _unbind?: () => void })._unbind = () => {
      window.removeEventListener("keydown", onDown);
      window.removeEventListener("keyup", onUp);
      this.canvas.removeEventListener("pointerdown", onPointer);
    };

    if (typeof window !== "undefined") {
      window.__controlsTest = {
        getYaw: () => this.qaYaw,
        getSpeed: () => this.qaSpeed,
        setKeys: (codes: string[]) => {
          this.inject = new Set(codes);
        },
      };
      window.__vfDebug = {
        skipToBoss: (stage?: number) => this.skipToBoss(stage),
        killBoss: () => {
          for (const e of this.enemies) {
            if (e.alive && isBossKind(e.kind)) this.hurt(e, 9999, false);
          }
        },
        hurtBoss: (n?: number) => {
          for (const e of this.enemies) {
            if (e.alive && isBossKind(e.kind)) this.hurt(e, n ?? e.maxHp * 0.38, false);
          }
        },
        grantBounty: () => {
          this.score = Math.max(this.score, Math.ceil(BUYOUT / 10));
          this.onChange();
        },
        forceOver: () => {
          this.ending = "mia";
          this.screen = "over";
          this.onChange();
        },
        forceContinue: () => this.offerContinue(),
        startDemo: () => this.startDemo(),
        abortDemo: () => this.abortDemo(),
        startHack: () => this.startHack(),
        stopHack: () => {
          this.hack = false;
        },
      };
    }
  }

  skipToBoss(stage?: number) {
    if (typeof stage === "number") this.stage = Math.max(0, Math.min(9, stage | 0));
    this.unlock();
    if (this.screen !== "play" && this.screen !== "pause") {
      this.lives = 3;
      this.bombs = 3;
      this.power = 2;
      this.dronesN = 2;
    }
    this.screen = "play";
    this.beginStage();
    this.bossWarn = true;
    this.stageT = 44;
    this.sfx.startMusic(this.stage);
    this.spawnBoss();
    this.onChange();
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.sfx.stopMusic();
    (this as unknown as { _unbind?: () => void })._unbind?.();
  }

  unlock() {
    this.sfx.unlock();
  }

  toggleMute() {
    this.muted = !this.muted;
    this.sfx.setMuted(this.muted);
    this.onChange();
  }

  choose(ship: ShipId) {
    this.ship = ship;
    this.onChange();
  }

  setDiff(d: DiffId) {
    this.diff = d;
    this.onChange();
  }

  setVs(on: boolean) {
    this.vs = on;
    if (on) this.crew = "solo";
    this.onChange();
  }

  setCrew(mode: CrewMode) {
    this.crew = mode;
    if (mode !== "solo") this.vs = false;
    if (this.p2Ship === this.ship) {
      this.p2Ship = this.ship === "azure" ? "crimson" : this.ship === "crimson" ? "iron" : "azure";
    }
    this.onChange();
  }

  chooseP2(ship: ShipId) {
    this.p2Ship = ship;
    this.onChange();
  }

  hasWing() {
    return !this.vs && (this.crew === "duo" || this.crew === "wingman");
  }

  diffOf() {
    return DIFFS[this.diff];
  }

  startRun() {
    this.idleT = 0;
    this.unlock();
    this.demo = false;
    this.score = 0;
    this.cpuScore = 0;
    this.loadout = emptyLoadout();
    this.ammo = emptyAmmo();
    this.startLives = Math.max(1, (this.ship === "iron" ? 4 : 3) + this.diffOf().lives);
    this.lives = this.startLives;
    this.bombs = 3;
    this.power = 0;
    this.dronesN = 1;
    this.mode = "lance";
    this.overdrive = 0;
    this.stage = 0;
    this.ending = "none";
    this.continues = 0;
    this.continueT = 0;
    this.railN = 0;
    this.p2invuln = 0;
    if (this.vs) {
      this.cpuShip = this.ship === "azure" ? "crimson" : this.ship === "crimson" ? "iron" : "azure";
      this.stage = Math.floor(Math.random() * 5);
      this.cx = GW / 2 + 40;
      this.cy = GH - 90;
      this.cpuFireCd = 0;
    } else if (this.hasWing()) {
      this.cpuShip = this.p2Ship;
      this.cx = GW / 2 + 40;
      this.cy = GH - 90;
      this.cpuFireCd = 0;
    }
    this.applyLoadout();
    this.beginStage();
    if (this.vs) {
      this.px = GW / 2 - 40;
      this.cx = GW / 2 + 40;
      this.cy = GH - 90;
      this.power = Math.max(this.power, 2);
      this.dronesN = Math.max(this.dronesN, 2);
      this.screen = "play";
      this.sfx.startMusic(this.stage);
    } else if (this.hack) {
      this.power = Math.max(this.power, 2);
      this.dronesN = Math.max(this.dronesN, 2);
      this.screen = "play";
      this.sfx.startMusic(0);
    } else {
      this.screen = "intro";
      this.sfx.startMusic(0);
    }
    this.onChange();
  }

  startHack() {
    this.unlock();
    this.hack = true;
    this.vs = false;
    this.crew = "solo";
    this.demo = false;
    this.diff = "normal";
    this.ship = (["azure", "crimson", "iron"] as ShipId[])[(Math.random() * 3) | 0]!;
    this.startRun();
  }

  dismissIntro() {
    if (this.screen !== "intro") return;
    this.screen = "brief";
    this.onChange();
  }

  dismissThanks() {
    if (this.screen !== "thanks") return;
    this.screen = "ending";
    this.onChange();
  }

  startDemo() {
    this.unlock();
    this.demo = true;
    this.vs = false;
    this.hack = false;
    this.ship = (["azure", "crimson", "iron"] as ShipId[])[this.demoPilotI % 3]!;
    this.demoPilotI += 1;
    this.stage = Math.floor(Math.random() * 7);
    this.score = 0;
    this.loadout = emptyLoadout();
    this.ammo = emptyAmmo();
    this.lives = 99;
    this.bombs = 3;
    this.power = 2;
    this.dronesN = 2;
    this.mode = "lance";
    this.overdrive = 0;
    this.demoT = 12;
    this.applyLoadout();
    this.beginStage();
    this.invuln = 0;
    this.power = Math.max(this.power, 2);
    this.dronesN = Math.max(this.dronesN, 2);
    this.screen = "play";
    this.sfx.startMusic(this.stage);
    this.onChange();
  }

  abortDemo() {
    if (!this.demo) return;
    this.demo = false;
    this.demoT = 0;
    this.idleT = 0;
    this.invuln = 0;
    this.sfx.stopMusic();
    this.screen = "title";
    this.onChange();
  }

  goTitle() {
    this.demo = false;
    this.vs = false;
    this.hack = false;
    this.hackBuf = "";
    this.demoT = 0;
    this.idleT = 0;
    this.invuln = 0;
    this.sfx.stopMusic();
    this.screen = "title";
    this.onChange();
  }

  openSelect(vs = false) {
    this.unlock();
    this.demo = false;
    this.vs = vs;
    this.idleT = 0;
    this.screen = "select";
    this.onChange();
  }

  launchCampaign() {
    this.vs = false;
    this.hack = false;
    this.startRun();
  }

  launchVs() {
    this.vs = true;
    this.hack = false;
    this.crew = "solo";
    this.startRun();
  }

  launchSortie() {
    this.unlock();
    this.applyLoadout();
    this.screen = "play";
    this.onChange();
  }

  openHangar() {
    this.screen = "shop";
    this.onChange();
  }

  priceOf(id: ShopId) {
    const item = SHOP.find((s) => s.id === id);
    if (!item) return 0;
    return shopPrice(item, this.ship, this.loadout[id]);
  }

  buy(id: ShopId) {
    const item = SHOP.find((s) => s.id === id);
    if (!item) return;
    if (!canEquip(item, this.ship)) return;
    if (this.loadout[id] >= item.max) return;
    if (item.cat === "special" && this.loadout[id] === 0 && specialCount(this.loadout) >= specialCap(this.ship)) return;
    const price = shopPrice(item, this.ship, this.loadout[id]);
    if (bountyOf(this.score) < price) return;
    this.score = Math.max(0, this.score - Math.ceil(price / 10));
    this.loadout[id] += 1;
    if (id === "plate") this.lives += 1;
    if (item.cat === "special") this.ammo[id] = Math.floor(item.ammo * ammoMul(this.ship));
    this.applyLoadout();
    this.sfx.pickup();
    this.onChange();
  }

  applyLoadout() {
    this.power = Math.max(this.power, this.loadout.cannon);
    this.dronesN = Math.min(4, Math.max(this.dronesN, 1 + this.loadout.drone));
    this.bombs = Math.min(7, Math.max(this.bombs, 3 + this.loadout.cell));
    this.armor = this.loadout.shield >= 2 ? 5 : this.loadout.shield >= 1 ? 3 : 0;
  }

  refundSpecials() {
    let back = 0;
    for (const item of SHOP) {
      if (item.cat !== "special" || this.loadout[item.id] <= 0) continue;
      const maxA = Math.max(1, Math.floor(item.ammo * ammoMul(this.ship)));
      const left = Math.max(0, this.ammo[item.id]);
      back += Math.floor(item.price * (left / maxA));
      this.loadout[item.id] = 0;
      this.ammo[item.id] = 0;
    }
    this.loadout.cell = 0;
    this.loadout.shield = 0;
    this.armor = 0;
    if (back > 0) this.score += Math.ceil(back / 10);
    return back;
  }

  snapshotClear(): ClearReport {
    const specials: ClearLine[] = [];
    let refund = 0;
    for (const item of SHOP) {
      if (item.cat !== "special" || this.loadout[item.id] <= 0) continue;
      const maxA = Math.max(1, Math.floor(item.ammo * ammoMul(this.ship)));
      const left = Math.max(0, this.ammo[item.id]);
      const cash = Math.floor(item.price * (left / maxA));
      refund += cash;
      specials.push({ name: item.name, ammo: left, refund: cash });
    }
    const kits = SHOP.filter((s) => s.cat === "kit" && this.loadout[s.id] > 0).map((s) => ({
      name: s.name,
      owned: this.loadout[s.id],
    }));
    return {
      stage: this.stage,
      last: this.stage >= 9,
      score: this.score,
      hi: Math.max(this.hi, this.score),
      bounty: bountyOf(this.score) + refund,
      refund,
      lives: this.lives,
      power: this.power,
      bombs: this.bombs,
      armor: this.armor,
      specials,
      kits,
    };
  }

  openClear() {
    this.clearReport = this.snapshotClear();
    this.refundSpecials();
    this.saveHi();
    this.clearReport.score = this.score;
    this.clearReport.bounty = this.bounty;
    this.clearReport.hi = this.hi;
    this.stageClearT = 0;
    if (this.vs) {
      this.openVsResult();
      return;
    }
    if (this.hack) {
      if (this.stage >= 9) {
        this.ending = bountyOf(this.score) >= BUYOUT ? "both" : "served";
        this.finishRun("thanks");
      } else {
        this.stage += 1;
        this.sfx.startMusic(this.stage);
        this.beginStage();
        this.screen = "play";
        this.onChange();
      }
      return;
    }
    this.screen = "clear";
    this.sfx.pickup();
    this.onChange();
  }

  openVsResult() {
    this.saveHi();
    this.sfx.stopMusic();
    this.pendingEnd = "vsresult";
    if (qualifies(this.score, this.hiTable)) {
      this.nameChars = ["A", "A", "A"];
      this.nameSlot = 0;
      this.screen = "name";
    } else {
      this.screen = "vsresult";
    }
    this.onChange();
  }

  continueFromClear() {
    if (!this.clearReport) return;
    if (this.clearReport.last) {
      this.ending = bountyOf(this.score) >= BUYOUT ? "both" : "served";
      this.finishRun("thanks");
      return;
    }
    this.stage += 1;
    this.sfx.startMusic(this.stage);
    this.beginStage();
    this.screen = "brief";
    this.onChange();
  }

  cashOut() {
    if (bountyOf(this.score) < BUYOUT) return;
    this.ending = "bought";
    this.finishRun("thanks");
  }

  desert() {
    this.ending = "desert";
    this.finishRun("over");
  }

  continuePrice() {
    return continueCost(this.continues);
  }

  canContinue() {
    return this.ending !== "desert" && bountyOf(this.score) >= this.continuePrice();
  }

  offerContinue() {
    this.ending = "mia";
    this.saveHi();
    if (this.hack) {
      this.finishRun("over");
      return;
    }
    this.continueT = 8.99;
    this.screen = "continue";
    this.sfx.warn();
    this.onChange();
  }

  doContinue() {
    if (this.screen !== "continue") return;
    const price = this.continuePrice();
    if (bountyOf(this.score) < price) return;
    this.score = Math.max(0, this.score - Math.ceil(price / 10));
    this.continues += 1;
    this.lives = Math.max(1, (this.ship === "iron" ? 4 : 3) + this.diffOf().lives);
    this.bombs = Math.max(this.bombs, 3);
    this.invuln = 2.4;
    this.continueT = 0;
    this.eBullets.forEach((b) => (b.alive = false));
    this.px = GW / 2;
    this.py = GH - 90;
    this.screen = "play";
    this.sfx.pickup();
    this.onChange();
  }

  skipContinue() {
    if (this.screen !== "continue") return;
    this.finishRun("over");
  }

  finishRun(next: Screen) {
    this.saveHi();
    this.pendingEnd = next;
    if (qualifies(this.score, this.hiTable)) {
      this.nameChars = ["A", "A", "A"];
      this.nameSlot = 0;
      this.screen = "name";
    } else {
      this.screen = next;
    }
    this.onChange();
  }

  handleNameKey(code: string) {
    if (code === "ArrowLeft" || code === "KeyA") this.nameSlot = (this.nameSlot + 2) % 3;
    if (code === "ArrowRight" || code === "KeyD") this.nameSlot = (this.nameSlot + 1) % 3;
    if (code === "ArrowUp" || code === "KeyW") this.nudgeName(1);
    if (code === "ArrowDown" || code === "KeyS") this.nudgeName(-1);
    if (code === "Enter" || code === "Space") this.submitName();
    this.onChange();
  }

  nudgeName(dir: number) {
    const i = ALPHA.indexOf(this.nameChars[this.nameSlot]);
    const n = (i + dir + ALPHA.length) % ALPHA.length;
    this.nameChars[this.nameSlot] = ALPHA[n] ?? "A";
    this.onChange();
  }

  setNameSlot(i: number) {
    this.nameSlot = ((i % 3) + 3) % 3;
    this.onChange();
  }

  submitName() {
    this.hiTable = insertScore({
      name: this.nameChars.join(""),
      score: this.score,
      ship: this.ship,
      stage: this.stage,
    });
    this.hi = this.hiTable[0]?.score ?? this.hi;
    this.screen = this.pendingEnd;
    this.onChange();
  }

  get bounty() {
    return bountyOf(this.score);
  }

  canBuy() {
    return bountyOf(this.score) >= BUYOUT;
  }

  beginStage() {
    this.stageT = 0;
    this.spawnI = -1;
    this.bossAlive = false;
    this.bossWarn = false;
    this.midCleared = false;
    this.midSpawnT = 0;
    this.stageClearT = 0;
    this.px = GW / 2;
    this.py = GH - 90;
    this.invuln = 1.4;
    if (this.ship === "azure") {
      this.speed = 228;
      this.hitR = 3.2;
    } else if (this.ship === "crimson") {
      this.speed = 188;
      this.hitR = 4.2;
    } else {
      this.speed = 150;
      this.hitR = 5.0;
    }
    this.applyLoadout();
    this.enemies.forEach((e) => (e.alive = false));
    this.eBullets.forEach((b) => (b.alive = false));
    this.pBullets.forEach((b) => (b.alive = false));
    this.items.forEach((i) => (i.alive = false));
    this.seedTerrain();
    if (this.vs || this.hasWing()) {
      this.px = GW / 2 - 40;
      this.py = GH - 90;
      this.cx = GW / 2 + 40;
      this.cy = GH - 90;
      this.p2invuln = 1.4;
    }
  }

  pause() {
    if (this.demo) return;
    if (this.screen === "play") {
      this.screen = "pause";
    } else if (this.screen === "pause") {
      this.screen = "play";
    }
    this.onChange();
  }

  held(code: string) {
    return this.keys.has(code) || this.inject.has(code);
  }

  loop = (t: number) => {
    this.raf = requestAnimationFrame(this.loop);
    if (!this.last) this.last = t;
    let dt = (t - this.last) / 1000;
    this.last = t;
    if (dt > 0.1) dt = 0.1;
    this.acc += dt;
    const step = 1 / 60;
    while (this.acc >= step) {
      if (this.screen === "play") this.update(step);
      if (this.screen === "title" && !this.demo) {
        this.idleT += step;
        if (this.idleT > 8) this.startDemo();
      }
      if (this.screen === "continue") {
        this.continueT -= step;
        if (this.continueT <= 0) this.finishRun("over");
      }
      this.acc -= step;
    }
    this.draw();
  };

  startLoop() {
    if (this.running) return;
    this.running = true;
    this.last = 0;
    this.raf = requestAnimationFrame(this.loop);
  }

  spawnE(partial: Partial<Ent> & { kind: Kind; x: number; y: number }): Ent {
    let e = this.enemies.find((x) => !x.alive);
    if (!e) {
      e = {
        alive: false,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        r: 12,
        hp: 1,
        maxHp: 1,
        kind: "wasp",
        t: 0,
        score: 100,
        ground: false,
        phase: 0,
        flash: 0,
        tag: 0,
        tell: 0,
        atk: 0,
      };
      this.enemies.push(e);
    }
    Object.assign(e, { vx: 0, vy: 40, r: 12, hp: 3, maxHp: 3, t: 0, score: 100, ground: false, phase: 0, flash: 0, tag: 0, tell: 0, atk: 0 }, partial, { alive: true });
    e.hp = Math.max(1, Math.ceil(e.hp * this.diffOf().hp));
    e.maxHp = e.hp;
    return e;
  }

  seedTerrain() {
    this.decor.forEach((d) => (d.alive = false));
    this.grounds.forEach((g) => (g.alive = false));
    const theme = STAGE_THEME[this.stage] ?? STAGE_THEME[0]!;
    for (let i = 0; i < 22; i++) {
      const kind = theme.decor[i % theme.decor.length]!;
      this.spawnDecor(kind, 20 + Math.random() * (GW - 40), Math.random() * GH);
    }
    if (theme.water === "sea") {
      for (let i = 0; i < 5; i++) this.spawnDecor("sea", GW / 2, i * 140);
    }
    for (let i = 0; i < 4; i++) {
      const kind = theme.targets[i % theme.targets.length]!;
      this.spawnGround(kind, 40 + Math.random() * (GW - 80), 40 + Math.random() * 280);
    }
  }

  spawnDecor(kind: Decor["kind"], x: number, y: number) {
    let d = this.decor.find((p) => !p.alive);
    if (!d) {
      d = { alive: true, x, y, kind, s: 1, flip: 1, phase: 0 };
      this.decor.push(d);
    }
    Object.assign(d, { alive: true, x, y, kind, s: 0.7 + Math.random() * 0.7, flip: Math.random() < 0.5 ? -1 : 1, phase: Math.random() * 6 });
    return d;
  }

  spawnGround(kind: TargetKind, x: number, y: number) {
    const spec = targetSpec(kind);
    let g = this.grounds.find((p) => !p.alive);
    if (!g) {
      g = { alive: true, x, y, kind, hp: spec.hp, maxHp: spec.hp, r: spec.r, score: spec.score, flash: 0, t: 0 };
      this.grounds.push(g);
    }
    const hp = Math.max(1, Math.ceil(spec.hp * this.diffOf().hp));
    Object.assign(g, { alive: true, x, y, kind, hp, maxHp: hp, r: spec.r, score: spec.score, flash: 0, t: 0 });
    return g;
  }

  updateTerrain(dt: number) {
    const vy = 40 + this.stage * 8;
    const theme = STAGE_THEME[this.stage] ?? STAGE_THEME[0]!;
    for (const d of this.decor) {
      if (!d.alive) continue;
      d.y += vy * dt;
      if (d.y > GH + 50) {
        d.y = -40 - Math.random() * 80;
        d.x = 18 + Math.random() * (GW - 36);
        d.kind = theme.decor[(Math.random() * theme.decor.length) | 0]!;
      }
    }
    for (const g of this.grounds) {
      if (!g.alive) continue;
      g.t += dt;
      g.flash = Math.max(0, g.flash - dt);
      g.y += vy * 0.55 * dt;
      if (g.y > GH + 40) g.alive = false;
      if ((g.kind === "bunker" || g.kind === "tower" || g.kind === "radar") && Math.floor(g.t) !== Math.floor(g.t - dt)) {
        this.aimFrom(g.x, g.y, 80, "#ffb347");
      }
    }
  }

  hurtGround(g: Ground, dmg: number, cpu: boolean) {
    g.hp -= dmg;
    g.flash = 0.12;
    this.spark(g.x, g.y, 4, "#fff4c2");
    this.sfx.hit();
    if (g.hp > 0) return;
    g.alive = false;
    const pts = g.score;
    if (cpu) this.cpuScore += pts;
    else this.score += pts;
    this.spark(g.x, g.y, 16, "#f0c14a");
    this.sfx.boom();
    this.shake = Math.max(this.shake, 5);
    if (!cpu) this.dropGroundLoot(g.x, g.y, g.kind);
  }

  dropGroundLoot(x: number, y: number, kind: TargetKind) {
    this.forceDrop(x, y, "G");
    const roll = Math.random();
    if (kind === "crate") {
      if (roll < 0.35) this.forceDrop(x + 8, y, "B");
      else if (roll < 0.48) this.forceDrop(x + 8, y, "1");
      else if (roll < 0.62) this.forceDrop(x + 8, y, "H");
    } else if (kind === "tower" || kind === "hangar") {
      if (roll < 0.22) this.forceDrop(x + 6, y, "1");
      else if (roll < 0.4) this.forceDrop(x + 6, y, "H");
      else if (roll < 0.55) this.forceDrop(x + 6, y, "B");
    } else if (roll < 0.16) this.forceDrop(x + 6, y, "H");
    else if (roll < 0.28) this.forceDrop(x + 6, y, "B");
    else if (roll < 0.34) this.forceDrop(x + 6, y, "1");
    else if (roll < 0.42) this.forceDrop(x + 6, y, "P");
  }

  bullet(list: Bullet[], b: Omit<Bullet, "alive" | "hit" | "pierce" | "vsGround" | "cpu" | "ay" | "spin" | "wait" | "split"> & { pierce?: boolean; vsGround?: boolean; cpu?: boolean; ay?: number; spin?: number; wait?: number; split?: number }) {
    const packed: Bullet = {
      ...b,
      pierce: b.pierce ?? false,
      vsGround: b.vsGround ?? false,
      cpu: b.cpu ?? false,
      ay: b.ay ?? 0,
      spin: b.spin ?? 0,
      wait: b.wait ?? 0,
      split: b.split ?? 0,
      hit: [],
      alive: true,
    };
    if (!packed.friendly) {
      const mul = this.diffOf().spd;
      packed.vx *= mul;
      packed.vy *= mul;
      packed.ay *= mul;
      packed.spin *= mul;
    }
    let x = list.find((i) => !i.alive);
    if (!x) {
      list.push(packed);
      return packed;
    }
    Object.assign(x, packed);
    return x;
  }

  spark(x: number, y: number, n: number, color: string) {
    for (let i = 0; i < n; i++) {
      let s = this.sparks.find((p) => !p.alive);
      const vx = (Math.random() - 0.5) * 180;
      const vy = (Math.random() - 0.5) * 180;
      if (!s) {
        s = { alive: true, x, y, vx, vy, life: 0.35 + Math.random() * 0.25, color, s: 1 + Math.random() * 2 };
        this.sparks.push(s);
      } else Object.assign(s, { alive: true, x, y, vx, vy, life: 0.35 + Math.random() * 0.25, color, s: 1 + Math.random() * 2 });
    }
  }

  dropItem(x: number, y: number) {
    this.forceDrop(x + (Math.random() * 16 - 8), y, "G");
    const roll = Math.random();
    let type: Item["type"] | null = null;
    if (roll < 0.1) type = "P";
    else if (roll < 0.14) type = "Q";
    else if (roll < 0.2) type = this.mode === "lance" ? "S" : "L";
    else if (roll < 0.26) type = "B";
    else if (roll < 0.3) type = "W";
    else if (roll < 0.32) type = "M";
    if (!type) return;
    this.forceDrop(x, y, type);
  }

  forceDrop(x: number, y: number, type: Item["type"]) {
    let it = this.items.find((i) => !i.alive);
    if (!it) {
      it = { alive: true, x, y, vy: 50, type };
      this.items.push(it);
    } else Object.assign(it, { alive: true, x, y, vy: 50, type });
  }

  update(dt: number) {
    if (this.demo) {
      this.demoT -= dt;
      if (this.demoT <= 0) {
        this.abortDemo();
        return;
      }
      this.steerAuto(dt, true);
    } else if (this.hack) {
      this.steerAuto(dt, true);
    } else {
      const duo = this.crew === "duo" && !this.vs;
      let mx = 0,
        my = 0;
      if (this.held("KeyA") || (!duo && this.held("ArrowLeft"))) mx -= 1;
      if (this.held("KeyD") || (!duo && this.held("ArrowRight"))) mx += 1;
      if (this.held("KeyW") || (!duo && this.held("ArrowUp"))) my -= 1;
      if (this.held("KeyS") || (!duo && this.held("ArrowDown"))) my += 1;
      if (this.touch.moving) {
        mx += this.touch.mx;
        my += this.touch.my;
      }
      const mag = Math.hypot(mx, my) || 1;
      if (mag > 1) {
        mx /= mag;
        my /= mag;
      }
      this.px += mx * this.speed * dt;
      this.py += my * this.speed * dt;
      this.px = Math.max(12, Math.min(GW - 12, this.px));
      this.py = Math.max(24, Math.min(GH - 24, this.py));
      this.qaSpeed = Math.hypot(mx, my) * this.speed;
      if (mx < -0.01) this.qaYaw += dt * 3;
      if (mx > 0.01) this.qaYaw -= dt * 3;

      if (duo) {
        let ox = 0,
          oy = 0;
        if (this.held("ArrowLeft")) ox -= 1;
        if (this.held("ArrowRight")) ox += 1;
        if (this.held("ArrowUp")) oy -= 1;
        if (this.held("ArrowDown")) oy += 1;
        const om = Math.hypot(ox, oy) || 1;
        if (om > 1) {
          ox /= om;
          oy /= om;
        }
        const spd = this.p2Ship === "azure" ? 228 : this.p2Ship === "crimson" ? 188 : 150;
        this.cx += ox * spd * dt;
        this.cy += oy * spd * dt;
        this.cx = Math.max(12, Math.min(GW - 12, this.cx));
        this.cy = Math.max(24, Math.min(GH - 24, this.cy));
      }
    }

    this.fireCd -= dt;
    this.bombCd -= dt;
    this.specialCd -= dt;
    this.cpuFireCd -= dt;
    this.invuln = Math.max(0, this.invuln - dt);
    this.p2invuln = Math.max(0, this.p2invuln - dt);
    this.overdrive += dt;
    this.chainT -= dt;
    if (this.chainT <= 0) this.chain = 1;
    this.shake = Math.max(0, this.shake - dt * 8);
    this.phaseBanner = Math.max(0, this.phaseBanner - dt);
    this.bg += dt * (40 + this.stage * 8);
    this.stageT += dt;

    const shooting = this.demo || this.hack || this.held("Space") || this.held("KeyJ") || this.touch.fire;
    if (shooting && this.fireCd <= 0) this.fire();
    if (!this.demo && !this.hack && (this.held("KeyZ") || this.touch.special) && this.specialCd <= 0) this.fireSpecial();
    if (!this.demo && !this.hack && (this.held("KeyX") || this.held("ShiftLeft") || this.held("KeyK") || this.touch.bomb) && this.bombCd <= 0) this.doBomb();
    const modeNow = this.held("KeyC") || this.held("KeyL") || this.touch.mode;
    if (!this.demo && !this.hack && modeNow && !this.modeHeld) this.toggleMode();
    this.modeHeld = modeNow;

    if (this.crew === "duo" && !this.vs && !this.hack && !this.demo) {
      if ((this.held("Enter") || this.held("NumpadEnter")) && this.cpuFireCd <= 0) {
        this.fireFrom(this.cx, this.cy, this.p2Ship, false);
      }
    }

    if (this.vs || this.crew === "wingman") this.updateCpu(dt);
    if (this.hack && this.bombCd <= 0) {
      let near = 0;
      for (const b of this.eBullets) {
        if (b.alive && Math.hypot(b.x - this.px, b.y - this.py) < 42) near += 1;
      }
      if (near >= 6) this.doBomb();
    }

    this.updateDrones(dt);
    this.updateTerrain(dt);
    this.spawnWaves();
    this.updateEnemies(dt);
    this.updateBullets(dt);
    this.updateItems(dt);
    this.updateSparks(dt);
    this.collisions();

    if (this.midSpawnT > 0 && this.stageClearT <= 0 && !this.bossAlive) {
      this.midSpawnT -= dt;
      if (this.midSpawnT <= 0) this.spawnBoss();
    }

    if (this.stageClearT > 0) {
      this.stageClearT -= dt;
      if (this.stageClearT <= 0) {
        if (this.demo) this.abortDemo();
        else this.openClear();
      }
    }
  }

  fire() {
    this.fireFrom(this.px, this.py, this.ship, false);
    for (const d of this.drones) {
      if (this.mode === "lance") {
        this.bullet(this.pBullets, { x: d.x, y: d.y, vx: 0, vy: -640, r: 2.2, dmg: 1.6, homing: false, friendly: true, color: "#5cff9a" });
      } else {
        const tgt = this.nearestEnemy(d.x, d.y);
        let vx = 0,
          vy = -380;
        if (tgt) {
          const a = Math.atan2(tgt.y - d.y, tgt.x - d.x);
          vx = Math.cos(a) * 380;
          vy = Math.sin(a) * 380;
        }
        this.bullet(this.pBullets, { x: d.x, y: d.y, vx, vy, r: 2, dmg: 0.9, homing: true, friendly: true, color: "#ffd36a" });
      }
    }
    if (this.overdrive >= 6) {
      this.overdrive = 0;
      this.sfx.overdrive();
      this.shake = 6;
      if (this.mode === "lance") {
        for (let i = -3; i <= 3; i++) {
          this.bullet(this.pBullets, { x: this.px + i * 10, y: this.py, vx: i * 12, vy: -700, r: 3.5, dmg: 4, homing: false, friendly: true, color: "#b8fff0" });
        }
      } else {
        for (let i = 0; i < 10; i++) {
          const a = -Math.PI / 2 + (i - 4.5) * 0.18;
          this.bullet(this.pBullets, { x: this.px, y: this.py, vx: Math.cos(a) * 420, vy: Math.sin(a) * 420, r: 2.4, dmg: 2, homing: true, friendly: true, color: "#ffb347" });
        }
      }
    }
  }

  fireFrom(x: number, y: number, ship: ShipId, cpu: boolean, slot: "p1" | "p2" = cpu ? "p2" : "p1") {
    const delay = ship === "azure" ? 0.08 : ship === "crimson" ? 0.1 : 0.13;
    if (slot === "p2") this.cpuFireCd = delay;
    else this.fireCd = delay;
    if (slot === "p1") this.sfx.shot();
    const dmgMul = ship === "azure" ? 0.9 : ship === "crimson" ? 1.15 : 1.5;
    const rank = cpu || slot === "p2" ? 2 : this.power;
    const dmg = (1 + rank * 0.35) * dmgMul;
    const shots = 1 + Math.min(2, Math.floor(rank / 2));
    const col = cpu ? "#ffd36a" : ship === "azure" ? "#7fe8ff" : ship === "crimson" ? "#ff8a6a" : "#c4d46a";
    for (let i = 0; i < shots; i++) {
      const ox = (i - (shots - 1) / 2) * 8;
      this.bullet(this.pBullets, { x: x + ox, y: y - 18, vx: ox * 4, vy: -520, r: 2.4, dmg, homing: false, friendly: true, color: col, cpu });
    }
    if (ship === "crimson") {
      this.bullet(this.pBullets, { x: x - 12, y: y - 8, vx: -140, vy: -500, r: 2.2, dmg: dmg * 0.85, homing: false, friendly: true, color: col, cpu });
      this.bullet(this.pBullets, { x: x + 12, y: y - 8, vx: 140, vy: -500, r: 2.2, dmg: dmg * 0.85, homing: false, friendly: true, color: col, cpu });
    }
    if (ship === "iron") {
      const s = 400;
      this.bullet(this.pBullets, { x: x - 6, y: y - 8, vx: -s * 0.7, vy: -s * 0.7, r: 2.8, dmg: dmg * 1.35, homing: false, friendly: true, color: "#c4d46a", vsGround: true, cpu });
      this.bullet(this.pBullets, { x: x + 6, y: y - 8, vx: s * 0.7, vy: -s * 0.7, r: 2.8, dmg: dmg * 1.35, homing: false, friendly: true, color: "#c4d46a", vsGround: true, cpu });
    }
  }

  steerAuto(dt: number, isPlayer: boolean) {
    let x = isPlayer ? this.px : this.cx;
    let y = isPlayer ? this.py : this.cy;
    const speed = isPlayer ? this.speed : 176;
    let dx = 0;
    let dy = 0;
    let threat = 1e9;
    for (const b of this.eBullets) {
      if (!b.alive) continue;
      const d = Math.hypot(b.x - x, b.y - y);
      if (d < 88 && d < threat) {
        threat = d;
        dx = x - b.x;
        dy = y - b.y;
      }
    }
    if (threat < 88) {
      const mag = Math.hypot(dx, dy) || 1;
      x += (dx / mag) * speed * dt;
      y += (dy / mag) * speed * 0.55 * dt;
    } else {
      const tgt = this.nearestEnemy(x, y);
      const weave = Math.sin(this.stageT * 1.35 + (isPlayer ? 0 : 1.8)) * 86;
      const tx = tgt ? tgt.x + weave * 0.25 : GW / 2 + weave;
      const ty = GH - 96 + Math.sin(this.stageT * 0.9 + (isPlayer ? 0 : 2)) * 18;
      const ax = tx - x;
      const ay = ty - y;
      const mag = Math.hypot(ax, ay) || 1;
      x += (ax / mag) * speed * 0.72 * dt;
      y += (ay / mag) * speed * 0.42 * dt;
    }
    x = Math.max(16, Math.min(GW - 16, x));
    y = Math.max(40, Math.min(GH - 28, y));
    if (isPlayer) {
      const mx = x - this.px;
      this.px = x;
      this.py = y;
      this.qaSpeed = Math.abs(mx) / Math.max(dt, 0.001);
      if (mx < -0.2) this.qaYaw += dt * 3;
      if (mx > 0.2) this.qaYaw -= dt * 3;
    } else {
      this.cx = x;
      this.cy = y;
    }
  }

  updateCpu(dt: number) {
    this.steerAuto(dt, false);
    if (this.cpuFireCd <= 0) this.fireFrom(this.cx, this.cy, this.cpuShip, this.vs, "p2");
  }

  fireSpecial() {
    const ids = SHOP.filter((s) => s.cat === "special" && this.loadout[s.id] > 0 && this.ammo[s.id] > 0).map((s) => s.id);
    if (!ids.length) return;
    this.specialCd = this.ship === "crimson" ? 0.16 : 0.26;
    this.sfx.shot();
    for (const id of ids) {
      this.ammo[id] -= 1;
      this.castSpecial(id);
    }
    this.onChange();
  }

  castSpecial(id: ShopId) {
    const tgt = this.nearestEnemy(this.px, this.py);
    const homingAt = (spd: number, dmg: number, r: number, color: string) => {
      let vx = 0,
        vy = -spd;
      if (tgt) {
        const a = Math.atan2(tgt.y - this.py, tgt.x - this.px);
        vx = Math.cos(a) * spd;
        vy = Math.sin(a) * spd;
      }
      this.bullet(this.pBullets, { x: this.px, y: this.py - 12, vx, vy, r, dmg, homing: true, friendly: true, color });
    };
    if (id === "wisp") homingAt(380, 1.6, 2.2, "#7fe8ff");
    if (id === "raven") homingAt(300, 3.2, 4.2, "#ff8a6a");
    if (id === "fork") {
      for (const ang of [-0.42, 0, 0.42]) {
        this.bullet(this.pBullets, { x: this.px, y: this.py - 16, vx: Math.sin(ang) * 640, vy: -Math.cos(ang) * 640, r: 2.4, dmg: 2.8, homing: false, friendly: true, color: "#b8fff0", pierce: true });
      }
    }
    if (id === "sunfire") {
      for (let i = -1; i <= 1; i++) {
        this.bullet(this.pBullets, { x: this.px + i * 10, y: this.py - 8, vx: i * 40, vy: -280, r: 3.4, dmg: 3.5, homing: false, friendly: true, color: "#ff7a2a", vsGround: true });
      }
    }
    if (id === "trident") {
      for (const vx of [-90, 0, 90]) {
        this.bullet(this.pBullets, { x: this.px, y: this.py - 12, vx, vy: -480, r: 2.4, dmg: 1.8, homing: false, friendly: true, color: "#e8c84a" });
      }
    }
    if (id === "spike") {
      this.bullet(this.pBullets, { x: this.px, y: this.py - 16, vx: 0, vy: -700, r: 3.8, dmg: 5.5, homing: false, friendly: true, color: "#d8fff8", pierce: true });
    }
    if (id === "starburst") {
      for (let i = 0; i < 16; i++) {
        const a = (i / 16) * Math.PI * 2 - Math.PI / 2;
        this.bullet(this.pBullets, { x: this.px, y: this.py, vx: Math.cos(a) * 360, vy: Math.sin(a) * 360, r: 2, dmg: 1.4, homing: false, friendly: true, color: "#ffd36a" });
      }
    }
    if (id === "sidegun") {
      this.bullet(this.pBullets, { x: this.px - 16, y: this.py, vx: -30, vy: -520, r: 2.2, dmg: 1.6, homing: false, friendly: true, color: "#ff8a6a", vsGround: true });
      this.bullet(this.pBullets, { x: this.px + 16, y: this.py, vx: 30, vy: -520, r: 2.2, dmg: 1.6, homing: false, friendly: true, color: "#ff8a6a", vsGround: true });
    }
    if (id === "ring") {
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        this.bullet(this.pBullets, { x: this.px + Math.cos(a) * 10, y: this.py + Math.sin(a) * 10, vx: Math.cos(a) * 280, vy: Math.sin(a) * 280, r: 2.6, dmg: 2.2, homing: false, friendly: true, color: "#9af0ff", pierce: true });
      }
    }
    if (id === "heavy") {
      this.shake = 12;
      this.invuln = Math.max(this.invuln, 0.5);
      for (const b of this.eBullets) if (b.alive) b.alive = false;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        this.hurt(e, e.ground ? 28 : 14, true);
      }
      for (const g of this.grounds) {
        if (!g.alive) continue;
        this.hurtGround(g, 22, false);
      }
      this.spark(this.px, this.py, 36, "#c4d46a");
    }
  }

  doBomb() {
    if (this.bombs <= 0) return;
    this.bombs -= 1;
    this.bombCd = 0.45;
    this.sfx.bomb();
    this.shake = 14;
    this.invuln = Math.max(this.invuln, 0.8);
    for (const b of this.eBullets) if (b.alive) b.alive = false;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      this.hurt(e, 18, true);
    }
    for (const g of this.grounds) {
      if (!g.alive) continue;
      this.hurtGround(g, 18, false);
    }
    this.spark(this.px, this.py, 40, "#fff4c2");
    this.onChange();
  }

  toggleMode() {
    this.mode = this.mode === "lance" ? "seek" : "lance";
    this.sfx.pickup();
    this.onChange();
  }

  nearestEnemy(x: number, y: number) {
    let best: Ent | null = null;
    let bd = 1e9;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const d = (e.x - x) ** 2 + (e.y - y) ** 2;
      if (d < bd) {
        bd = d;
        best = e;
      }
    }
    return best;
  }

  updateDrones(dt: number) {
    while (this.drones.length < this.dronesN) this.drones.push({ x: this.px, y: this.py, ang: Math.random() * 6 });
    this.drones.length = this.dronesN;
    for (let i = 0; i < this.drones.length; i++) {
      const d = this.drones[i];
      d.ang += dt * (this.mode === "seek" ? 2.4 : 1.4);
      const rad = 28 + i * 6;
      const a = d.ang + (i * Math.PI * 2) / Math.max(1, this.drones.length);
      const tx = this.px + Math.cos(a) * rad;
      const ty = this.py + Math.sin(a) * rad * 0.7;
      d.x += (tx - d.x) * Math.min(1, dt * 12);
      d.y += (ty - d.y) * Math.min(1, dt * 12);
    }
  }

  spawnWaves() {
    const st = this.stage;
    const t = this.stageT;
    const tick = Math.floor(t * 2 * this.diffOf().dens);
    if (tick === this.spawnI) return;
    this.spawnI = tick;

    const lane = () => 30 + Math.random() * (GW - 60);

    if (t < 41 && !this.bossAlive && !this.bossWarn) {
      const ground = st === 0 || st === 2 || st === 3 || st === 5 || st === 8;
      const air = st === 1 || st === 4 || st === 6 || st === 9;
      const sea = st === 7;
      const cave = st === 5;
      if (tick % 4 === 0) {
        this.spawnE({ kind: "wasp", x: lane(), y: -20, vy: 90 + st * 8, hp: 2, r: 11, score: 120 });
      }
      if (tick % 7 === 0) {
        this.spawnE({ kind: "hornet", x: lane(), y: -24, vy: 70, vx: Math.random() < 0.5 ? 40 : -40, hp: 5, r: 14, score: 220 });
      }
      if (ground && tick % 10 === 0) {
        this.spawnE({ kind: "gunbarge", x: lane(), y: -30, vy: 32, hp: 14, r: 18, score: 400, ground: true });
      }
      if (ground && tick % 13 === 0) {
        this.spawnE({ kind: "strider", x: lane(), y: GH + 10, vy: -25, hp: 10, r: 16, score: 350, ground: true });
      }
      if ((air || st >= 2) && tick % 9 === 0) {
        this.spawnE({ kind: "eyepod", x: lane(), y: -20, vy: 50, hp: 8, r: 14, score: 300 });
      }
      if (air && tick % 8 === 0) {
        this.spawnE({ kind: "lancejet", x: lane(), y: -20, vy: 120, hp: 4, r: 12, score: 200 });
      }
      if ((sea || st >= 4) && tick % 15 === 0) {
        this.spawnE({ kind: "keel", x: Math.random() < 0.5 ? -20 : GW + 20, y: 80 + Math.random() * 200, vx: Math.random() < 0.5 ? 70 : -70, vy: 20, hp: 16, r: 20, score: 500 });
      }
      if ((sea || cave) && tick % 8 === 0) {
        this.spawnE({ kind: "mine", x: lane(), y: -16, vy: 55, hp: 2, r: 8, score: 80 });
      }
      if (tick % 17 === 0) {
        this.spawnE({ kind: "gilded", x: lane(), y: -28, vy: 45, hp: 12, r: 18, score: 480 });
      }
      if (st >= 3 && tick % 19 === 0) {
        this.spawnE({ kind: "redtide", x: lane(), y: -36, vy: 30, hp: 22, r: 22, score: 700 });
      }
      if (tick % 11 === 0) {
        const theme = STAGE_THEME[st] ?? STAGE_THEME[0]!;
        const kind = theme.targets[tick % theme.targets.length]!;
        this.spawnGround(kind, lane(), -28);
      }
    }

    if (t >= 41 && !this.bossAlive && this.stageClearT === 0 && !this.bossWarn) {
      this.bossWarn = true;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        e.alive = false;
        this.spark(e.x, e.y, 8, "#ffe08a");
      }
      for (const b of this.eBullets) b.alive = false;
      this.sfx.warn();
      this.onChange();
    }

    if (t >= 44 && !this.bossAlive && this.stageClearT === 0 && this.midSpawnT <= 0) {
      this.spawnBoss();
    }
  }

  spawnBoss() {
    const meta = this.stage === 7 && !this.midCleared ? SUB_BOSS : BOSS_META[this.stage] ?? BOSS_META[9];
    this.bossAlive = true;
    this.bossWarn = true;
    const patrol = meta.kind === "dunehauler" || meta.kind === "siegecrawler" || meta.kind === "battlekeel" || meta.kind === "krakenkeel";
    this.spawnE({
      kind: meta.kind,
      x: GW / 2,
      y: -50,
      vy: 0,
      vx: patrol ? 50 : 0,
      hp: meta.hp,
      r: meta.r,
      score: meta.score,
      ground: meta.kind === "siegecrawler" || meta.kind === "rootcitadel" || meta.kind === "dunehauler" || meta.kind === "silohydra",
    });
    this.sfx.boss();
    this.shake = 8;
    this.setAtk("");
    this.onChange();
  }

  pulse(e: Ent, dt: number, hz: number) {
    const h = hz * this.diffOf().fire;
    return Math.floor(e.t * h) !== Math.floor((e.t - dt) * h);
  }

  minionCount() {
    let n = 0;
    for (const e of this.enemies) if (e.alive && !isBossKind(e.kind)) n += 1;
    return n;
  }

  updateEnemies(dt: number) {
    for (const e of this.enemies) {
      if (!e.alive) continue;
      e.t += dt;
      e.flash = Math.max(0, e.flash - dt);
      if (isBossKind(e.kind)) {
        this.updateBoss(e, dt);
        const maxY = e.kind === "skypike" ? 380 : 228;
        e.x = Math.max(36, Math.min(GW - 36, e.x));
        e.y = Math.max(40, Math.min(maxY, e.y));
        continue;
      }
      if (e.kind === "wasp") {
        e.x += Math.sin(e.t * 3) * 40 * dt;
        e.y += e.vy * dt;
        if (e.t > 0.6 && Math.floor(e.t * 2) !== Math.floor((e.t - dt) * 2)) this.aimShot(e, 90, 1);
      } else if (e.kind === "hornet") {
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        if (e.x < 20 || e.x > GW - 20) e.vx *= -1;
        if (Math.floor(e.t * 1.5) !== Math.floor((e.t - dt) * 1.5)) this.spread(e, 3, 110, 0.35);
      } else if (e.kind === "gunbarge" || e.kind === "strider") {
        e.y += e.vy * dt;
        if (e.kind === "strider") e.x += Math.sin(e.t * 1.2) * 50 * dt;
        if (Math.floor(e.t) !== Math.floor(e.t - dt)) this.spread(e, 5, 80, 0.5);
      } else if (e.kind === "eyepod") {
        e.y += e.vy * dt;
        e.x += Math.sin(e.t * 2) * 70 * dt;
        if (Math.floor(e.t * 0.8) !== Math.floor((e.t - dt) * 0.8)) this.ring(e, 10, 70);
      } else if (e.kind === "lancejet") {
        e.y += e.vy * dt;
        this.aimShot(e, 160, 0.9);
      } else if (e.kind === "keel") {
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        if (Math.floor(e.t * 2) !== Math.floor((e.t - dt) * 2)) this.aimShot(e, 100, 1);
      } else if (e.kind === "gilded") {
        e.y += (e.vy + Math.sin(e.t) * 10) * dt;
        e.x += Math.sin(e.t * 0.8) * 30 * dt;
        if (Math.floor(e.t * 1.2) !== Math.floor((e.t - dt) * 1.2)) this.spread(e, 5, 95, 0.45, "#f0c14a");
      } else if (e.kind === "redtide") {
        e.y += e.vy * dt;
        e.x += Math.sin(e.t * 0.7) * 40 * dt;
        if (Math.floor(e.t * 1.4) !== Math.floor((e.t - dt) * 1.4)) this.spread(e, 4, 90, 0.4, "#ff3b4a");
      } else if (e.kind === "mine") {
        e.y += e.vy * dt;
        e.x += Math.sin(e.t * 4) * 20 * dt;
      } else if (e.kind === "aegis") {
        e.x = GW / 2 + Math.sin(e.t * 0.7) * 80;
        e.y += (70 - e.y) * dt * 0.4;
        if (Math.floor(e.t * 1.1) !== Math.floor((e.t - dt) * 1.1)) this.ring(e, 12, 75);
      } else {
        e.y += e.vy * dt;
        e.x += e.vx * dt;
      }
      if (e.y > GH + 50 || e.y < -80 || e.x < -80 || e.x > GW + 80) e.alive = false;
    }
  }

  updateBoss(e: Ent, dt: number) {
    const spec = e.kind === "krakenkeel" ? SUB_BOSS : BOSS_META[this.stage] ?? BOSS_META[0];
    const restY = spec.restY;
    const entering = e.t < 1.7;
    e.tell = Math.max(0, e.tell - dt);

    const ratio = e.hp / e.maxHp;
    const want = ratio < 0.33 ? 2 : ratio < 0.6 ? 1 : 0;
    if (want > e.phase) {
      e.phase = want;
      this.phaseBanner = 1.7;
      this.spark(e.x, e.y, 28, "#fff4c2");
      this.shake = 10;
      this.sfx.phase();
      this.ring(e, 16, 85, "#fff4c2");
      this.setAtk(this.bossPhaseName(e.kind, e.phase));
      this.onChange();
    }

    if (entering) {
      e.y += (restY - e.y) * Math.min(1, dt * 1.8);
      this.setAtk("");
    }

    const ready = !entering;
    const p = e.phase;
    if (e.kind === "siegecrawler") this.bossSiege(e, dt, p, ready, restY, entering);
    else if (e.kind === "phantomwing") this.bossPhantom(e, dt, p, ready, restY);
    else if (e.kind === "rootcitadel") this.bossRoot(e, dt, p, ready, restY, entering);
    else if (e.kind === "dunehauler" || e.kind === "redmaw") this.bossDune(e, dt, p, ready, restY, entering);
    else if (e.kind === "skypike") this.bossPike(e, dt, p, ready, restY, entering);
    else if (e.kind === "silohydra") this.bossSilo(e, dt, p, ready, restY, entering);
    else if (e.kind === "ironalbatross") this.bossAlbatross(e, dt, p, ready, restY);
    else if (e.kind === "krakenkeel") this.bossKraken(e, dt, p, ready, restY, entering);
    else if (e.kind === "battlekeel" || e.kind === "harborking") this.bossKeel(e, dt, p, ready, restY, entering);
    else if (e.kind === "arsenalgate" || e.kind === "gyre") this.bossGate(e, dt, p, ready, restY, entering);
    else if (e.kind === "skycathedral" || e.kind === "crowncore") this.bossCathedral(e, dt, p, ready, restY, entering);
    else if (e.kind === "solarmoth") {
      e.x = GW / 2 + Math.sin(e.t * 0.72) * 100;
      e.y = restY + Math.sin(e.t * 1.35) * 18;
      if (ready && this.pulse(e, dt, 1.0)) this.spread(e, p === 0 ? 5 : 7, 96, 0.36, "#f0c14a");
    } else if (!entering) {
      e.y += (restY - e.y) * Math.min(1, dt * 1.5);
    }
  }

  cycleU(e: Ent, period: number) {
    return Math.max(0, e.t - 1.7) % period;
  }

  windAtk(e: Ent, u: number, t0: number, t1: number, name: string, wind = 0.42) {
    if (u >= t0 - wind && u < t1) {
      this.setAtk(name);
      if (u < t0) {
        e.tell = Math.max(e.tell, t0 - u);
        if (u < t0 - wind + 0.05) this.sfx.tell();
      }
      return u >= t0;
    }
    return false;
  }

  setAtk(name: string) {
    if (this.bossAtk === name) return;
    this.bossAtk = name;
    this.onChange();
  }

  bossPhaseName(kind: Kind, phase: number) {
    const table: Partial<Record<Kind, [string, string, string]>> = {
      siegecrawler: ["RADAR SWEEP", "SEARCH GRID", "SATURATION"],
      phantomwing: ["GHOST GUNS", "AFTERBURN", "DOUBLE IMAGE"],
      rootcitadel: ["CANOPY RAIN", "SEED BURST", "ROOT LASH"],
      dunehauler: ["TREAD WAKE", "CHARGE", "DUST STORM"],
      redmaw: ["TREAD WAKE", "CHARGE", "DUST STORM"],
      skypike: ["DIVE BOMB", "TRENCH RUN", "FREE FALL"],
      silohydra: ["SEQUENCE", "CROSSFIRE", "FULL SALVO"],
      ironalbatross: ["CARPET", "ENGINE WASH", "BAY DUMP"],
      krakenkeel: ["SNORKEL", "MINEFIELD", "MAGAZINE"],
      battlekeel: ["BROADSIDE", "CROSSING FIRE", "MAG DUMP"],
      harborking: ["BROADSIDE", "CROSSING FIRE", "MAG DUMP"],
      arsenalgate: ["HINGE SWEEP", "LOCKDOWN", "GATE SLAM"],
      gyre: ["HINGE SWEEP", "LOCKDOWN", "GATE SLAM"],
      skycathedral: ["SHIELD SPOKES", "DOUBLE HELIX", "CROWN FLOWER"],
      crowncore: ["SHIELD SPOKES", "DOUBLE HELIX", "CROWN FLOWER"],
    };
    return table[kind]?.[phase] ?? "";
  }

  bossSiege(e: Ent, dt: number, p: number, ready: boolean, restY: number, entering: boolean) {
    if (!entering) e.y += (restY - e.y) * Math.min(1, dt * 1.6);
    e.x += e.vx * (p >= 2 ? 1.45 : 1) * dt;
    if (e.x < 52 || e.x > GW - 52) e.vx *= -1;
    e.atk = 0;
    if (!ready) return;
    const period = p === 0 ? 5.6 : p === 1 ? 5.0 : 4.4;
    const u = this.cycleU(e, period);
    const mx = e.x;
    const my = e.y - 16;
    if (this.windAtk(e, u, 0.48, 1.9, "RADAR SWEEP")) {
      const ang = Math.PI * 0.16 + (u - 0.48) * (p >= 2 ? 2.4 : 2.05);
      e.atk = ang;
      if (this.pulse(e, dt, p >= 2 ? 5.2 : 4.4)) {
        this.radarRay(mx, my, ang, p >= 1 ? 5 : 4, 98, "#c4d46a");
        if (p >= 2) this.radarRay(mx, my, Math.PI - ang, 4, 94, "#9aaa3a");
      }
    }
    if (this.windAtk(e, u, 2.35, 3.65, "RANGE SHELLS")) {
      if (this.pulse(e, dt, 1.25)) this.shells(e.x, e.y + 10, p >= 2 ? 5 : 3, this.px, "#9aaa3a");
    }
    if (p === 0 && this.windAtk(e, u, 3.95, 5.1, "MAST PING")) {
      if (this.pulse(e, dt, 1.15)) this.aimFrom(mx, my, 114, "#c4d46a");
    }
    if (p >= 1 && this.windAtk(e, u, 3.85, period - 0.12, p >= 2 ? "SATURATION" : "SEARCH GRID")) {
      if (this.pulse(e, dt, 0.88)) this.downFan(mx, my, 5, 108, 0.22, "#c4d46a");
      if (p >= 2 && this.pulse(e, dt, 0.52)) this.wallShot(this.px, 44, 9, 92, e.y + 18, "#9aaa3a");
    }
  }

  bossPhantom(e: Ent, dt: number, p: number, ready: boolean, restY: number) {
    e.tag = Math.max(0, e.tag - dt);
    e.x = GW / 2 + Math.sin(e.t * 1.18) * (102 + p * 10);
    e.y = restY + Math.sin(e.t * 2.05) * 16;
    if (!ready) return;
    const period = p === 0 ? 4.9 : p === 1 ? 4.3 : 3.9;
    const u = this.cycleU(e, period);
    const gx = e.x - 34;
    const hx = e.x + 34;
    const gy = e.y + 6;
    if (this.windAtk(e, u, 0.5, 1.45, "GHOST GUNS")) {
      if (this.pulse(e, dt, 1.05)) {
        e.tag = p >= 2 ? 0.95 : 0.7;
        this.spark(e.x, e.y + 10, 6, "#cfd8e6");
        this.aimFrom(e.x - 10, e.y + 8, 150, "#8aa0b8");
        this.aimFrom(e.x + 10, e.y + 8, 150, "#8aa0b8");
        this.aimFrom(gx, gy, 128, "#6a8098");
        this.aimFrom(hx, gy, 128, "#6a8098");
      }
    }
    if (p >= 1 && this.windAtk(e, u, 1.85, 2.75, "AFTERBURN")) {
      if (this.pulse(e, dt, 1.15)) {
        e.tag = 0.82;
        this.spread(e, 5, 128, 0.22, "#cfd8e6");
        this.bloom(e.x, e.y + 4, 6, 68, 0.4, "#8aa0b8", e.t);
      }
    } else if (p === 0 && this.windAtk(e, u, 2.15, 3.35, "GHOST GUNS")) {
      if (this.pulse(e, dt, 0.95)) {
        e.tag = 0.68;
        this.aimFrom(e.x - 10, e.y + 8, 150, "#8aa0b8");
        this.aimFrom(e.x + 10, e.y + 8, 150, "#8aa0b8");
      }
    }
    if (p >= 2 && this.windAtk(e, u, 2.95, 3.75, "DOUBLE IMAGE")) {
      if (this.pulse(e, dt, 1.8)) {
        e.tag = 0.95;
        this.ring(e, 10, 74, "#8aa0b8");
        this.bloom(gx, e.y, 7, 62, 0.36, "#6a8098");
      }
    }
    if (ready && p >= 2 && e.tag > 0 && this.pulse(e, dt, 2.0)) this.aimFrom(e.x, e.y + 6, 170, "#cfd8e6");
  }

  bossRoot(e: Ent, dt: number, p: number, ready: boolean, restY: number, entering: boolean) {
    if (!entering) e.y += (restY - e.y) * Math.min(1, dt * 1.4);
    e.x = GW / 2 + Math.sin(e.t * 0.25) * 18;
    if (!ready) return;
    const period = p === 0 ? 5.3 : p === 1 ? 4.8 : 4.4;
    const u = this.cycleU(e, period);
    if (this.pulse(e, dt, p === 0 ? 0.62 : 0.78)) {
      this.aimFrom(e.x - 18, e.y - 12, 102, "#7cb86a");
      this.aimFrom(e.x + 18, e.y - 12, 102, "#7cb86a");
      this.aimFrom(e.x - 18, e.y + 12, 92, "#7cb86a");
      this.aimFrom(e.x + 18, e.y + 12, 92, "#7cb86a");
    }
    if (this.windAtk(e, u, 0.45, 2.05, "CANOPY RAIN")) {
      if (this.pulse(e, dt, 1.15)) {
        const skip = this.px < e.x - 12 ? 0 : this.px > e.x + 12 ? 2 : 1;
        for (let i = 0; i < 3; i++) {
          if (i === skip) continue;
          this.shot(e.x + (i - 1) * 26, e.y - 16, Math.PI / 2, 108, "#5a8a3a");
        }
      }
    }
    if (p >= 1 && this.windAtk(e, u, 2.3, 3.45, "SEED BURST")) {
      if (this.pulse(e, dt, 0.72)) {
        this.shot(e.x - 10, e.y - 16, Math.PI / 2, 36, "#7cb86a", { wait: 0.55, split: 5, r: 3.4 });
        this.shot(e.x + 10, e.y - 16, Math.PI / 2, 36, "#7cb86a", { wait: 0.55, split: 5, r: 3.4 });
        this.downFan(e.x, e.y - 16, 5, 96, 0.2, "#5a8a3a");
      }
    }
    if (p >= 2 && this.windAtk(e, u, 3.55, period - 0.1, "ROOT LASH")) {
      if (this.pulse(e, dt, 1.35)) {
        this.arcBurst(e.x - 18, e.y + 8, 4, 90, 0.55, 1.45, "#5a8a3a", { spin: 1.35 });
        this.arcBurst(e.x + 18, e.y + 8, 4, 90, 1.7, 2.6, "#5a8a3a", { spin: -1.35 });
      }
      if (this.pulse(e, dt, 0.78)) this.streamShot(e.x, e.y - 14, 124, "#7cb86a");
    }
  }

  bossDune(e: Ent, dt: number, p: number, ready: boolean, restY: number, entering: boolean) {
    if (!entering) e.y += (restY - e.y) * Math.min(1, dt * 1.5);
    const period = p === 0 ? 5.8 : p === 1 ? 5.2 : 4.4;
    const u = this.cycleU(e, period);
    const charging = ready && p >= 1 && this.windAtk(e, u, 0.38, 1.58, "CHARGE");
    if (charging) {
      e.tag = 1;
      const dir = Math.sign(this.px - e.x) || (e.vx >= 0 ? 1 : -1);
      e.vx = dir * (p >= 2 ? 155 : 124);
    } else {
      e.tag = 0;
      if (p >= 2 && Math.abs(e.vx) < 78) e.vx = (e.vx >= 0 ? 1 : -1) * 82;
    }
    e.x += e.vx * dt;
    if (e.x < 52 || e.x > GW - 52) e.vx *= -1;
    if (!ready) return;
    if (charging && this.pulse(e, dt, 2.4)) {
      const dir = e.vx >= 0 ? 1 : -1;
      const a = Math.PI / 2 + dir * 0.38;
      this.arcBurst(e.x, e.y + 10, 5, 120, a - 0.3, a + 0.3, "#ff3b4a");
    }
    if (this.windAtk(e, u, p >= 1 ? 1.85 : 0.4, p >= 2 ? 3.25 : period - 0.15, "TREAD WAKE")) {
      if (this.pulse(e, dt, 2.6)) {
        this.shot(e.x - 22, e.y + 12, Math.PI / 2, 64, "#c47a3a", { wait: 0.2, r: 3.1 });
        this.shot(e.x + 22, e.y + 12, Math.PI / 2, 64, "#c47a3a", { wait: 0.2, r: 3.1 });
      }
      if (this.pulse(e, dt, p === 0 ? 0.78 : 0.92)) {
        this.spreadFrom(e.x - 22, e.y + 10, p >= 1 ? 5 : 3, 104, 0.3, "#ff3b4a");
        this.spreadFrom(e.x + 22, e.y + 10, p >= 1 ? 5 : 3, 104, 0.3, "#ff3b4a");
      }
    }
    if (p >= 2 && this.windAtk(e, u, 3.4, period - 0.08, "DUST STORM")) {
      if (this.pulse(e, dt, 0.7)) this.waveRow(e.y + 14, 7, 88, 42, "#ff7a90", e.t * 2);
      if (this.pulse(e, dt, 0.55)) this.shells(e.x, e.y + 8, 4, this.px, "#ff3b4a");
    }
    if (p >= 1 && this.pulse(e, dt, 1.5)) this.aimFrom(e.x, e.y + 8, 148, "#ff7a90");
    if (p >= 1 && this.pulse(e, dt, 0.36) && this.minionCount() < 4) {
      this.spawnE({ kind: "wasp", x: e.x + (Math.random() < 0.5 ? -28 : 28), y: e.y + 18, vy: 95, hp: 2, r: 11, score: 80 });
    }
  }

  bossPike(e: Ent, dt: number, p: number, ready: boolean, restY: number, entering: boolean) {
    const period = p === 0 ? 5.2 : p === 1 ? 4.2 : 3.35;
    const u = entering ? 0 : ((e.t - 1.7) % period) / period;
    const diving = u > 0.42 && u < 0.78;
    e.tag = diving ? 1 : 0;
    const diveY = p === 0 ? 222 : p === 1 ? 308 : 368;
    const ty = diving ? diveY : restY;
    e.y += (ty - e.y) * Math.min(1, dt * 2.55);
    e.x = GW / 2 + Math.sin(e.t * (diving ? 0.32 : 0.92)) * (diving ? 38 : 96);
    const atk = p >= 2 ? "FREE FALL" : p === 1 ? "TRENCH RUN" : "DIVE BOMB";
    if (u > 0.34 && u <= 0.42) {
      e.tell = (0.42 - u) * period;
      this.setAtk(atk);
      if (u < 0.36) this.sfx.tell();
    }
    if (diving) this.setAtk(atk);
    if (!ready) return;
    if (!diving && this.pulse(e, dt, 1.05)) this.spread(e, p >= 2 ? 5 : 3, 112, 0.26, "#cfd8e6");
    if (diving && this.pulse(e, dt, p === 0 ? 1.7 : 2.25)) {
      this.downFan(e.x, e.y + 14, p >= 2 ? 7 : 5, 128, 0.18, "#ffae42");
      this.aimFrom(e.x, e.y + 12, 158, "#ffae42");
      if (p >= 1) {
        this.shot(e.x - 8, e.y + 14, Math.PI / 2, 128, "#ffae42", { spin: 2.15 });
        this.shot(e.x + 8, e.y + 14, Math.PI / 2, 128, "#ffae42", { spin: -2.15 });
      }
      if (p >= 2) this.shot(e.x, e.y + 16, Math.PI / 2, 42, "#ff7a22", { ay: 150, r: 3.5 });
    }
    if (!diving && u > 0.78 && this.pulse(e, dt, 1.35)) {
      this.shot(e.x, e.y + 8, Math.PI / 2 + 0.52, 110, "#cfd8e6");
      this.shot(e.x, e.y + 8, Math.PI / 2 - 0.52, 110, "#cfd8e6");
    }
  }

  bossSilo(e: Ent, dt: number, p: number, ready: boolean, restY: number, entering: boolean) {
    if (!entering) e.y += (restY - e.y) * Math.min(1, dt * 1.5);
    e.x = GW / 2 + Math.sin(e.t * 0.3) * 24;
    if (!ready) return;
    const period = p === 0 ? 4.6 : p === 1 ? 4.2 : 3.8;
    const u = this.cycleU(e, period);
    const open = Math.floor(e.t * 1.05) % 3;
    const name = p >= 2 ? "FULL SALVO" : p === 1 ? "CROSSFIRE" : "SEQUENCE";
    if (this.windAtk(e, u, 0.4, period - 0.2, name, 0.32)) {
      if (this.pulse(e, dt, 1.15)) {
        const fire = p === 0 ? [open] : p === 1 ? [open, (open + 2) % 3] : [0, 1, 2];
        for (const slot of fire) {
          const ox = (slot - 1) * 16;
          this.streamAng(e.x + ox, e.y + 8, Math.PI / 2, p >= 2 ? 5 : 4, 126, "#e8c84a");
          if (p >= 2) this.shot(e.x + ox, e.y + 8, Math.PI / 2 + (slot - 1) * 0.18, 118, "#ffae42");
        }
      }
    }
    if (p >= 1 && this.pulse(e, dt, 0.62)) {
      const ox = (open - 1) * 16;
      this.spreadFrom(e.x + ox, e.y + 6, 3, 118, 0.28, "#ffae42");
    }
    if (p >= 2 && this.pulse(e, dt, 0.85)) {
      for (const ox of [-16, 0, 16]) this.shot(e.x + ox, e.y + 6, Math.PI / 2, 108, "#e8c84a", { spin: ox * 0.08 });
    }
  }

  bossAlbatross(e: Ent, dt: number, p: number, ready: boolean, restY: number) {
    const hold = restY + (p >= 2 ? 38 : 0);
    e.y += (hold - e.y) * Math.min(1, dt * 1.45);
    e.x = GW / 2 + Math.sin(e.t * 0.4) * 70;
    if (!ready) return;
    const period = p >= 2 ? 4.4 : 5.0;
    const u = this.cycleU(e, period);
    if (this.windAtk(e, u, 0.4, 2.1, "CARPET")) {
      if (this.pulse(e, dt, p >= 2 ? 1.55 : 1.35)) {
        const n = p >= 2 ? 4 : 3;
        for (let i = -n; i <= n; i++) {
          this.bullet(this.eBullets, {
            x: e.x + i * 14,
            y: e.y + 16,
            vx: i * 6,
            vy: 86,
            r: 2.8,
            dmg: 1,
            homing: false,
            friendly: false,
            color: "#8aa0b8",
            wait: 0.38,
          });
        }
      }
    }
    if (p >= 1 && this.windAtk(e, u, 2.25, 3.45, "ENGINE WASH")) {
      if (this.pulse(e, dt, 0.78)) {
        this.shot(e.x - 18, e.y + 8, Math.PI / 2, 112, "#cfd8e6", { spin: 1.15 });
        this.shot(e.x + 18, e.y + 8, Math.PI / 2, 112, "#cfd8e6", { spin: -1.15 });
        this.downFan(e.x - 18, e.y + 8, 3, 118, 0.16, "#cfd8e6");
        this.downFan(e.x + 18, e.y + 8, 3, 118, 0.16, "#cfd8e6");
      }
    }
    if (p >= 2 && this.windAtk(e, u, 3.55, period - 0.08, "BAY DUMP")) {
      if (this.pulse(e, dt, 0.7)) {
        for (let i = -2; i <= 2; i++) {
          this.shot(e.x + i * 16, e.y + 16, Math.PI / 2, 32, "#8aa0b8", { wait: 0.48, split: 4, r: 3.3 });
        }
      }
      if (this.pulse(e, dt, 0.82)) this.aimFrom(e.x, e.y + 10, 138, "#cfd8e6");
    }
  }

  bossKraken(e: Ent, dt: number, p: number, ready: boolean, restY: number, entering: boolean) {
    if (!entering) e.y += (restY - e.y) * Math.min(1, dt * 1.5);
    e.x += e.vx * dt;
    if (e.x < 48 || e.x > GW - 48) e.vx *= -1;
    if (!ready) return;
    const period = p === 0 ? 4.8 : p === 1 ? 4.4 : 4.0;
    const u = this.cycleU(e, period);
    if (this.windAtk(e, u, 0.4, 1.9, "SNORKEL")) {
      if (this.pulse(e, dt, 0.92)) {
        const a = Math.atan2(this.py - (e.y - 14), this.px - e.x);
        this.streamAng(e.x, e.y - 14, a, 3, 148, "#3d9a9a");
      }
    }
    if (p >= 1 && this.windAtk(e, u, 2.1, 3.3, "MINEFIELD")) {
      if (this.pulse(e, dt, 0.44)) this.spawnE({ kind: "mine", x: e.x, y: e.y + 18, vy: 50, hp: 2, r: 8, score: 80 });
      if (this.pulse(e, dt, 0.95)) {
        this.arcBurst(e.x - 16, e.y + 8, 4, 96, 0.45, 1.5, "#3d9a9a", { spin: 1.2 });
        this.arcBurst(e.x + 16, e.y + 8, 4, 96, 1.64, 2.7, "#3d9a9a", { spin: -1.2 });
      }
    }
    if (p >= 2 && this.windAtk(e, u, 3.4, period - 0.08, "MAGAZINE")) {
      if (this.pulse(e, dt, 0.7)) this.downFan(e.x, e.y + 12, 5, 122, 0.2, "#3d9a9a");
      if (this.pulse(e, dt, 0.55)) this.shot(e.x, e.y + 12, Math.PI / 2, 28, "#5ec8c8", { wait: 0.5, split: 5, r: 3.6 });
    } else if (p === 0 && this.windAtk(e, u, 2.2, 3.6, "SNORKEL")) {
      if (this.pulse(e, dt, 0.7)) this.aimFrom(e.x, e.y - 14, 152, "#3d9a9a");
    }
  }

  bossKeel(e: Ent, dt: number, p: number, ready: boolean, restY: number, entering: boolean) {
    if (!entering) e.y += (restY - e.y) * Math.min(1, dt * 1.5);
    e.x = GW / 2 + Math.sin(e.t * 0.38) * 48;
    if (!ready) return;
    const period = p === 0 ? 5.2 : p === 1 ? 4.7 : 4.2;
    const u = this.cycleU(e, period);
    if (this.windAtk(e, u, 0.4, 2.0, "BROADSIDE")) {
      if (this.pulse(e, dt, p === 0 ? 0.72 : 0.88)) {
        this.arcBurst(e.x - 22, e.y + 6, 4, 118, 0.7, 1.35, "#6aa4ff");
        this.arcBurst(e.x + 22, e.y + 6, 4, 118, 1.8, 2.44, "#6aa4ff");
        this.aimFrom(e.x - 22, e.y + 6, 124, "#6aa4ff");
        this.aimFrom(e.x + 22, e.y + 6, 124, "#6aa4ff");
      }
    }
    if (p >= 1 && this.windAtk(e, u, 2.2, 3.35, "CROSSING FIRE")) {
      if (this.pulse(e, dt, 0.9)) {
        this.xBurst(e.x, e.y + 4, 96, "#6aa4ff");
        this.ring(e, 10, 70, "#6aa4ff");
      }
    }
    if (p >= 2 && this.windAtk(e, u, 3.45, period - 0.08, "MAG DUMP")) {
      if (this.pulse(e, dt, 0.58)) this.downFan(e.x, e.y + 10, 7, 118, 0.16, "#6aa4ff");
      if (this.pulse(e, dt, 0.5)) this.waveRow(e.y + 12, 8, 92, 36, "#8ec0ff", e.t);
    }
    if (this.pulse(e, dt, 0.32) && this.minionCount() < 5) {
      this.spawnE({ kind: "wasp", x: e.x + (Math.random() * 40 - 20), y: e.y + 22, vy: 88, hp: 2, r: 11, score: 80 });
    }
    if (p >= 2 && this.pulse(e, dt, 0.28) && this.minionCount() < 6) {
      this.spawnE({ kind: "hornet", x: e.x, y: e.y + 16, vy: 70, vx: Math.random() < 0.5 ? 50 : -50, hp: 5, r: 14, score: 160 });
    }
  }

  bossGate(e: Ent, dt: number, p: number, ready: boolean, restY: number, entering: boolean) {
    e.x = GW / 2 + Math.sin(e.t * 0.85) * 92;
    if (!entering) e.y += (restY - e.y) * Math.min(1, dt * 1.5);
    if (!ready) return;
    const period = p === 0 ? 4.8 : p === 1 ? 4.4 : 4.0;
    const u = this.cycleU(e, period);
    const lx = e.x - 26;
    const rx = e.x + 26;
    if (this.windAtk(e, u, 0.4, 2.05, "HINGE SWEEP")) {
      const ang = e.t * (p >= 1 ? 2.1 : 1.65);
      e.atk = ang;
      if (this.pulse(e, dt, 4.6)) {
        this.radarRay(lx, e.y, ang, 4, 86, "#d8e4f0");
        this.radarRay(rx, e.y, Math.PI - ang, 4, 86, "#d8e4f0");
      }
    } else e.atk = 0;
    if (p >= 1 && this.windAtk(e, u, 2.2, 3.25, "LOCKDOWN")) {
      if (this.pulse(e, dt, 0.78)) {
        const skip = Math.round(this.px / 60) * 60;
        for (let x = 30; x < GW; x += 60) {
          if (Math.abs(x - skip) < 28) continue;
          this.shot(x, e.y + 6, Math.PI / 2, 104, "#9ad8ff");
        }
        this.aimFrom(lx, e.y, 132, "#9ad8ff");
        this.aimFrom(rx, e.y, 132, "#9ad8ff");
      }
    }
    if (p >= 2 && this.windAtk(e, u, 3.35, period - 0.08, "GATE SLAM")) {
      if (this.pulse(e, dt, 0.52)) this.wallShot(this.px, 40, 10, 100, e.y + 8, "#cfd8e6");
      if (this.pulse(e, dt, 0.85)) {
        this.arcBurst(lx, e.y, 5, 108, 0.35, 1.25, "#9ad8ff");
        this.arcBurst(rx, e.y, 5, 108, 1.9, 2.8, "#9ad8ff");
      }
    } else if (p === 0 && this.windAtk(e, u, 2.3, 3.7, "HINGE SWEEP")) {
      if (this.pulse(e, dt, 0.95)) this.ring(e, 8, 68, "#d8e4f0");
    }
  }

  bossCathedral(e: Ent, dt: number, p: number, ready: boolean, restY: number, entering: boolean) {
    e.x = GW / 2 + Math.sin(e.t * 0.55) * (58 + p * 18);
    if (!entering) e.y += (restY - e.y) * Math.min(1, dt * 1.3);
    if (!ready) return;
    if (p === 0) {
      this.setAtk("SHIELD SPOKES");
      if (this.pulse(e, dt, 0.95)) {
        const spin = e.t * 1.05;
        const gap = 0.62;
        for (let i = 0; i < 10; i++) {
          const a = (i / 10) * Math.PI * 2 + e.t * 0.15;
          let diff = a - spin;
          while (diff > Math.PI) diff -= Math.PI * 2;
          while (diff < -Math.PI) diff += Math.PI * 2;
          if (Math.abs(diff) < gap) continue;
          this.shot(e.x, e.y, a, 72, "#3ec8ff");
        }
      }
    } else if (p === 1) {
      this.setAtk("DOUBLE HELIX");
      if (this.pulse(e, dt, 7.2)) {
        const a = e.t * 3.6;
        this.shot(e.x, e.y, a, 86, "#7fe8ff");
        this.shot(e.x, e.y, a + Math.PI, 86, "#3ec8ff");
      }
      if (this.pulse(e, dt, 0.76)) this.spread(e, 5, 128, 0.24, "#3ec8ff");
    } else {
      this.setAtk("CROWN FLOWER");
      if (this.pulse(e, dt, 7.4)) {
        const a = e.t * 4.4;
        for (let i = 0; i < 3; i++) this.shot(e.x, e.y, a + (i * Math.PI * 2) / 3, 94, "#7fe8ff");
      }
      if (this.pulse(e, dt, 0.48)) this.bloom(e.x, e.y, 8, 64, 0.32, "#3ec8ff", e.t);
      if (this.pulse(e, dt, 0.68)) this.spread(e, 3, 142, 0.2, "#fff");
      if (this.pulse(e, dt, 0.4)) this.ring(e, 8, 70, "#3ec8ff");
    }
  }

  aimShot(e: Ent, spd: number, chance: number, color = "#ff5a6a") {
    if (Math.random() > chance) return;
    this.aimFrom(e.x, e.y, spd, color);
  }
  aimFrom(x: number, y: number, spd: number, color: string) {
    const a = Math.atan2(this.py - y, this.px - x);
    this.bullet(this.eBullets, { x, y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, r: 2.6, dmg: 1, homing: false, friendly: false, color });
  }
  spread(e: Ent, n: number, spd: number, arc: number, color = "#ff7a90") {
    this.spreadFrom(e.x, e.y, n, spd, arc, color);
  }
  spreadFrom(x: number, y: number, n: number, spd: number, arc: number, color: string) {
    const base = Math.atan2(this.py - y, this.px - x);
    for (let i = 0; i < n; i++) {
      const a = base + (i - (n - 1) / 2) * arc;
      this.bullet(this.eBullets, { x, y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, r: 2.4, dmg: 1, homing: false, friendly: false, color });
    }
  }
  ring(e: Ent, n: number, spd: number, color = "#c77dff") {
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + e.t;
      this.bullet(this.eBullets, { x: e.x, y: e.y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, r: 2.3, dmg: 1, homing: false, friendly: false, color });
    }
  }
  downFan(x: number, y: number, n: number, spd: number, arc: number, color: string) {
    const base = Math.PI / 2;
    for (let i = 0; i < n; i++) {
      const a = base + (i - (n - 1) / 2) * arc;
      this.bullet(this.eBullets, { x, y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, r: 2.5, dmg: 1, homing: false, friendly: false, color });
    }
  }
  mortar(x: number, y: number, n: number, color: string) {
    for (let i = 0; i < n; i++) {
      const vx = (i - (n - 1) / 2) * 30;
      const vy = 52 + (i % 2) * 14;
      this.bullet(this.eBullets, { x, y, vx, vy, r: 3.4, dmg: 1, homing: false, friendly: false, color });
    }
  }
  wallShot(gapX: number, gapW: number, n: number, spd: number, y: number, color: string) {
    for (let i = 0; i < n; i++) {
      const x = 18 + (i / Math.max(1, n - 1)) * (GW - 36);
      if (Math.abs(x - gapX) < gapW) continue;
      this.bullet(this.eBullets, { x, y, vx: 0, vy: spd, r: 2.5, dmg: 1, homing: false, friendly: false, color });
    }
  }
  streamShot(x: number, y: number, spd: number, color: string) {
    const a = Math.atan2(this.py - y, this.px - x);
    for (let i = 0; i < 3; i++) {
      this.bullet(this.eBullets, {
        x: x - Math.cos(a) * i * 10,
        y: y - Math.sin(a) * i * 10,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        r: 2.3,
        dmg: 1,
        homing: false,
        friendly: false,
        color,
      });
    }
  }
  shot(x: number, y: number, ang: number, spd: number, color: string, extra?: { r?: number; ay?: number; spin?: number; wait?: number; split?: number }) {
    this.bullet(this.eBullets, {
      x,
      y,
      vx: Math.cos(ang) * spd,
      vy: Math.sin(ang) * spd,
      r: extra?.r ?? 2.5,
      dmg: 1,
      homing: false,
      friendly: false,
      color,
      ay: extra?.ay ?? 0,
      spin: extra?.spin ?? 0,
      wait: extra?.wait ?? 0,
      split: extra?.split ?? 0,
    });
  }
  radarRay(x: number, y: number, ang: number, n: number, spd: number, color: string) {
    for (let i = 0; i < n; i++) this.shot(x, y, ang, spd + i * 14, color, { r: 2.3 });
  }
  shells(x: number, y: number, n: number, targetX: number, color: string) {
    for (let i = 0; i < n; i++) {
      const tx = targetX + (i - (n - 1) / 2) * 30;
      const t = 1.12 + (i % 2) * 0.16;
      this.bullet(this.eBullets, {
        x,
        y,
        vx: (tx - x) / t,
        vy: 46 + (i % 2) * 12,
        r: 3.5,
        dmg: 1,
        homing: false,
        friendly: false,
        color,
        ay: 145,
      });
    }
  }
  bloom(x: number, y: number, n: number, spd: number, wait: number, color: string, rot = 0) {
    for (let i = 0; i < n; i++) this.shot(x, y, (i / n) * Math.PI * 2 + rot, spd, color, { wait, r: 2.8 });
  }
  arcBurst(x: number, y: number, n: number, spd: number, a0: number, a1: number, color: string, extra?: { r?: number; spin?: number; wait?: number }) {
    for (let i = 0; i < n; i++) {
      const a = n === 1 ? (a0 + a1) / 2 : a0 + (a1 - a0) * (i / (n - 1));
      this.shot(x, y, a, spd, color, extra);
    }
  }
  streamAng(x: number, y: number, ang: number, n: number, spd: number, color: string) {
    for (let i = 0; i < n; i++) {
      this.shot(x - Math.cos(ang) * i * 9, y - Math.sin(ang) * i * 9, ang, spd, color, { r: 2.4 });
    }
  }
  waveRow(y: number, n: number, spd: number, amp: number, color: string, phase = 0) {
    for (let i = 0; i < n; i++) {
      const x = 24 + (i / Math.max(1, n - 1)) * (GW - 48);
      this.bullet(this.eBullets, {
        x,
        y,
        vx: Math.sin(phase + i * 0.7) * amp,
        vy: spd,
        r: 2.5,
        dmg: 1,
        homing: false,
        friendly: false,
        color,
      });
    }
  }
  xBurst(x: number, y: number, spd: number, color: string) {
    for (let i = 0; i < 4; i++) this.shot(x, y, Math.PI / 4 + (i * Math.PI) / 2, spd, color);
  }
  bossShieldBlocks(e: Ent, b: Bullet) {
    if (e.kind !== "skycathedral" && e.kind !== "crowncore") return false;
    if (e.phase >= 2) return false;
    const d = Math.hypot(b.x - e.x, b.y - e.y);
    if (d > e.r * 1.38 + b.r || d < e.r * 0.5) return false;
    const ang = Math.atan2(b.y - e.y, b.x - e.x);
    const spin = e.t * (e.phase === 0 ? 1.05 : 1.45);
    const gap = e.phase === 0 ? 0.62 : 0.46;
    let diff = ang - spin;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    return Math.abs(diff) > gap;
  }
  bossHitMul(e: Ent, bx: number, by: number) {
    if (!isBossKind(e.kind)) return 1;
    switch (e.kind) {
      case "siegecrawler":
        return by < e.y - 8 ? 1.45 : 0.85;
      case "phantomwing":
        return e.tag > 0 || e.flash > 0 ? 1.2 : 0.35;
      case "rootcitadel":
        return by < e.y - 10 ? 1.5 : 0.8;
      case "dunehauler":
      case "redmaw":
        return Math.abs(bx - e.x) > e.r * 0.38 ? 1.4 : 0.85;
      case "skypike":
        return e.tag > 0.5 && by > e.y ? 1.65 : 0.8;
      case "silohydra": {
        const lid = bx < e.x - 8 ? 0 : bx > e.x + 8 ? 2 : 1;
        const want = Math.floor(e.tag) % 3;
        if (lid === want) {
          e.tag = want + 1;
          return 1.55;
        }
        return 0.72;
      }
      case "ironalbatross":
        return Math.abs(bx - e.x) > 10 && Math.abs(bx - e.x) < 28 ? 1.5 : 0.85;
      case "krakenkeel":
        return e.phase === 0 ? (by < e.y - 4 ? 1.55 : 0.8) : Math.abs(bx - e.x) < 12 && by > e.y ? 1.45 : 0.85;
      case "battlekeel":
      case "harborking":
        return Math.abs(bx - e.x) < 12 && by > e.y - 4 ? 1.5 : 0.85;
      case "arsenalgate":
      case "gyre":
        return Math.abs(bx - e.x) > e.r * 0.42 ? 1.5 : 0.82;
      case "skycathedral":
      case "crowncore":
        return e.phase >= 2 ? 1.25 : 1.15;
      default:
        return 1;
    }
  }

  updateBullets(dt: number) {
    for (const b of this.pBullets) {
      if (!b.alive) continue;
      if (b.homing) {
        const t = this.nearestEnemy(b.x, b.y);
        if (t) {
          const a = Math.atan2(t.y - b.y, t.x - b.x);
          b.vx += Math.cos(a) * 420 * dt;
          b.vy += Math.sin(a) * 420 * dt;
          const s = Math.hypot(b.vx, b.vy) || 1;
          const cap = 460;
          b.vx = (b.vx / s) * cap;
          b.vy = (b.vy / s) * cap;
        }
      }
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      if (b.y < -20 || b.y > GH + 20 || b.x < -20 || b.x > GW + 20) b.alive = false;
    }
    for (const b of this.eBullets) {
      if (!b.alive) continue;
      if (b.wait > 0) {
        b.wait -= dt;
        if (b.wait > 0) continue;
        if (b.split > 0) {
          const n = b.split;
          const spd = 78;
          b.alive = false;
          for (let i = 0; i < n; i++) {
            const a = (i / n) * Math.PI * 2 + b.x * 0.01;
            this.bullet(this.eBullets, {
              x: b.x,
              y: b.y,
              vx: Math.cos(a) * spd,
              vy: Math.sin(a) * spd,
              r: 2.2,
              dmg: 1,
              homing: false,
              friendly: false,
              color: b.color,
            });
          }
          continue;
        }
      }
      if (b.ay) b.vy += b.ay * dt;
      if (b.spin) {
        const a = Math.atan2(b.vy, b.vx) + b.spin * dt;
        const s = Math.hypot(b.vx, b.vy) || 1;
        b.vx = Math.cos(a) * s;
        b.vy = Math.sin(a) * s;
      }
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      if (b.y < -20 || b.y > GH + 20 || b.x < -20 || b.x > GW + 20) b.alive = false;
    }
  }

  updateItems(dt: number) {
    for (const it of this.items) {
      if (!it.alive) continue;
      it.y += it.vy * dt;
      it.x += Math.sin(it.y * 0.04) * 20 * dt;
      if (it.y > GH + 20) it.alive = false;
      const nearP1 = Math.hypot(it.x - this.px, it.y - this.py) < 18;
      const nearP2 = (this.vs || this.hasWing()) && Math.hypot(it.x - this.cx, it.y - this.cy) < 18;
      if (nearP1 || nearP2) {
        it.alive = false;
        this.sfx.pickup();
        if (it.type === "P") this.power = Math.min(4, this.power + 1);
        else if (it.type === "Q") this.power = Math.min(4, this.power + 2);
        else if (it.type === "L") {
          this.mode = "lance";
          this.dronesN = Math.min(4, this.dronesN + 1);
        } else if (it.type === "S") {
          this.mode = "seek";
          this.dronesN = Math.min(4, this.dronesN + 1);
        } else if (it.type === "B") this.bombs = Math.min(7, this.bombs + 1);
        else if (it.type === "G") this.score += 120;
        else if (it.type === "M") this.score += 1000;
        else if (it.type === "1") this.lives = Math.min(7, this.lives + 1);
        else if (it.type === "H") this.armor = Math.min(5, this.armor + 1);
        else if (it.type === "W") {
          for (const s of SHOP) {
            if (s.cat === "special" && this.loadout[s.id] > 0) this.ammo[s.id] += 10;
          }
          this.score += 200;
        } else this.score += 200;
        this.onChange();
      }
    }
  }

  updateSparks(dt: number) {
    for (const s of this.sparks) {
      if (!s.alive) continue;
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.life -= dt;
      if (s.life <= 0) s.alive = false;
    }
  }

  collisions() {
    for (const b of this.pBullets) {
      if (!b.alive) continue;
      let spent = false;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        if (isBossKind(e.kind) && this.bossShieldBlocks(e, b)) {
          if (b.hit.includes(e)) continue;
          b.hit.push(e);
          this.spark(b.x, b.y, 4, "#7fe8ff");
          if (!b.pierce) {
            b.alive = false;
            spent = true;
            break;
          }
          continue;
        }
        if (Math.hypot(b.x - e.x, b.y - e.y) < e.r + b.r) {
          if (b.hit.includes(e)) continue;
          b.hit.push(e);
          const dmg = (b.vsGround && e.ground ? b.dmg * 1.8 : b.dmg) * this.bossHitMul(e, b.x, b.y);
          this.hurt(e, dmg, false, b.cpu);
          if (!b.pierce) {
            b.alive = false;
            spent = true;
            break;
          }
        }
      }
      if (spent || !b.alive) continue;
      for (const g of this.grounds) {
        if (!g.alive) continue;
        if (Math.hypot(b.x - g.x, b.y - g.y) < g.r + b.r) {
          const dmg = b.vsGround ? b.dmg * 1.8 : b.dmg;
          this.hurtGround(g, dmg, b.cpu);
          if (!b.pierce) {
            b.alive = false;
            break;
          }
        }
      }
    }
    if (!this.demo && this.invuln <= 0) {
      let hit = false;
      for (const b of this.eBullets) {
        if (!b.alive) continue;
        if (Math.hypot(b.x - this.px, b.y - this.py) < this.hitR + b.r) {
          b.alive = false;
          this.playerHit("p1");
          hit = true;
          break;
        }
      }
      if (!hit) {
        for (const e of this.enemies) {
          if (!e.alive) continue;
          if (Math.hypot(e.x - this.px, e.y - this.py) < this.hitR + e.r * 0.55) {
            this.playerHit("p1");
            hit = true;
            break;
          }
        }
      }
    }
    if (!this.demo && this.hasWing() && this.p2invuln <= 0) {
      const hr = this.p2Ship === "azure" ? 3.2 : this.p2Ship === "crimson" ? 4.2 : 5;
      for (const b of this.eBullets) {
        if (!b.alive) continue;
        if (Math.hypot(b.x - this.cx, b.y - this.cy) < hr + b.r) {
          b.alive = false;
          this.playerHit("p2");
          break;
        }
      }
    }
  }

  playerHit(who: "p1" | "p2" = "p1") {
    if (this.demo) return;
    const x = who === "p2" ? this.cx : this.px;
    const y = who === "p2" ? this.cy : this.py;
    if (this.armor > 0) {
      this.armor -= 1;
      if (who === "p2") this.p2invuln = 1.2;
      else this.invuln = this.ship === "iron" ? 1.6 : 1.1;
      this.shake = 7;
      this.sfx.pickup();
      this.spark(x, y, 16, "#f0c14a");
      this.eBullets.forEach((b) => (b.alive = false));
      this.onChange();
      return;
    }
    this.sfx.die();
    this.lives -= 1;
    if (who === "p2") this.p2invuln = 2;
    else this.invuln = this.ship === "iron" ? 2.8 : 2;
    this.shake = 12;
    this.power = Math.max(this.loadout.cannon, this.power - 1);
    this.dronesN = Math.max(1 + this.loadout.drone, this.dronesN - 1);
    this.spark(x, y, 24, "#3ec8ff");
    this.eBullets.forEach((b) => (b.alive = false));
    if (this.lives <= 0) {
      if (this.vs) this.openVsResult();
      else this.offerContinue();
    }
    this.onChange();
  }

  hurt(e: Ent, dmg: number, bomb: boolean, cpu = false) {
    e.hp -= dmg;
    e.flash = 0.1;
    this.spark(e.x, e.y, 3, "#fff");
    this.sfx.hit();
    if (e.hp <= 0) {
      e.alive = false;
      const airOnGround = !e.ground && this.enemies.some((g) => g.alive && g.ground && Math.hypot(g.x - e.x, g.y - e.y) < 40);
      if (!cpu && airOnGround) this.chain = Math.min(32, this.chain * 2);
      if (!cpu) this.chainT = 2.2;
      const pts = Math.floor(e.score * (cpu ? 1 : this.chain));
      if (cpu) this.cpuScore += pts;
      else this.score += pts;
      const boss = isBossKind(e.kind);
      this.spark(e.x, e.y, bomb || boss ? 22 : 12, boss ? "#3ec8ff" : "#ffb347");
      this.sfx.boom();
      this.shake = Math.max(this.shake, bomb || boss ? 12 : 4);
      if (!cpu) this.dropItem(e.x, e.y);
      if (boss) {
        this.bossAlive = false;
        this.eBullets.forEach((b) => (b.alive = false));
        if (e.kind === "krakenkeel") {
          this.midCleared = true;
          this.midSpawnT = 2.1;
          this.bossWarn = true;
          if (cpu) this.cpuScore += 1500;
          else this.score += 1500;
          if (!cpu) this.forceDrop(e.x, e.y, "P");
          this.sfx.warn();
        } else {
          this.bossWarn = false;
          this.stageClearT = 2.6;
          if (cpu) this.cpuScore += 2500;
          else this.score += 2500;
          if (!cpu) {
            this.forceDrop(e.x - 12, e.y, "P");
            this.forceDrop(e.x + 12, e.y, "B");
            this.forceDrop(e.x, e.y + 10, "G");
            this.forceDrop(e.x - 18, e.y + 8, "G");
            this.forceDrop(e.x + 18, e.y + 8, "G");
          }
        }
        this.onChange();
      }
    }
  }

  saveHi() {
    if (this.score > this.hi) {
      this.hi = this.score;
      localStorage.setItem(HS_KEY, String(this.hi));
    }
  }

  incomingSpec() {
    return this.stage === 7 && !this.midCleared ? SUB_BOSS : BOSS_META[this.stage];
  }

  bossHud() {
    const e = this.enemies.find((x) => x.alive && isBossKind(x.kind));
    const spec = e ? (e.kind === "krakenkeel" ? SUB_BOSS : BOSS_META[this.stage]) : this.incomingSpec();
    return {
      warning: (this.bossWarn || this.midSpawnT > 0) && !e && this.stageClearT <= 0,
      name: spec?.name ?? "",
      hp: e ? e.hp : 0,
      max: e ? e.maxHp : 0,
      phase: e ? e.phase + 1 : 0,
      weak: spec?.weak ?? "",
      atk: e ? this.bossAtk : "",
    };
  }

  draw() {
    const c = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.clearRect(0, 0, w, h);
    const sx = w / GW;
    const sy = h / GH;
    const shx = (Math.random() - 0.5) * this.shake;
    const shy = (Math.random() - 0.5) * this.shake;
    c.setTransform(sx, 0, 0, sy, shx * sx, shy * sy);

    this.drawBg(c);
    if (this.screen === "play" || this.screen === "pause" || this.screen === "over" || this.screen === "win") {
      this.drawWorld(c);
    }
  }

  drawBg(c: CanvasRenderingContext2D) {
    const palettes = [
      ["#0c1208", "#2a3a18", "#7cb86a"],
      ["#080814", "#1a2048", "#6ad0ff"],
      ["#081208", "#143018", "#4a8a32"],
      ["#1a1208", "#5a3a14", "#e0a040"],
      ["#140a08", "#4a2210", "#ff7a22"],
      ["#08060c", "#1a1020", "#8a5aff"],
      ["#0a1018", "#3a5070", "#c8d8f0"],
      ["#040c14", "#0a2840", "#3ec8ff"],
      ["#0a0a10", "#2a2a32", "#cfd8e6"],
      ["#05060c", "#102030", "#3ec8ff"],
    ];
    const pal = palettes[this.stage] || palettes[0];
    const g = c.createLinearGradient(0, 0, 0, GH);
    g.addColorStop(0, pal[1]);
    g.addColorStop(1, pal[0]);
    c.fillStyle = g;
    c.fillRect(0, 0, GW, GH);
    c.save();
    c.globalAlpha = 0.35;
    for (let i = 0; i < 18; i++) {
      const y = ((this.bg * 0.4 + i * 48) % (GH + 40)) - 20;
      c.strokeStyle = pal[2];
      c.lineWidth = i % 4 === 0 ? 2 : 0.6;
      c.beginPath();
      c.moveTo(0, y);
      c.lineTo(GW, y);
      c.stroke();
    }
    c.globalAlpha = 0.5;
    for (let i = 0; i < 40; i++) {
      const x = (i * 47 + this.bg * 0.2) % GW;
      const y = (i * 73 + this.bg) % GH;
      c.fillStyle = pal[2];
      c.fillRect(x, y, 1.2, 3 + (i % 3));
    }
    c.restore();
  }

  drawWorld(c: CanvasRenderingContext2D) {
    for (const d of this.decor) {
      if (d.alive) drawDecor(c, d, this.stageT);
    }
    for (const g of this.grounds) {
      if (g.alive) drawGround(c, g);
    }
    for (const it of this.items) {
      if (!it.alive) continue;
      c.fillStyle =
        it.type === "P" || it.type === "Q"
          ? "#f0c14a"
          : it.type === "B"
            ? "#ff3b4a"
            : it.type === "L"
              ? "#5cff9a"
              : it.type === "G"
                ? "#f0c14a"
                : it.type === "M"
                  ? "#ff8ad4"
                  : it.type === "W"
                    ? "#6dff8a"
                    : it.type === "1"
                      ? "#ff5a6a"
                      : it.type === "H"
                        ? "#f0c14a"
                    : "#ffae42";
      c.beginPath();
      c.arc(it.x, it.y, it.type === "G" ? 6 : 7, 0, Math.PI * 2);
      c.fill();
      if (it.type === "G") {
        c.fillStyle = "#fff4c2";
        c.beginPath();
        c.arc(it.x - 1.5, it.y - 1.5, 2, 0, Math.PI * 2);
        c.fill();
      } else {
        c.fillStyle = "#070b14";
        c.font = "bold 8px sans-serif";
        c.textAlign = "center";
        c.fillText(it.type, it.x, it.y + 3);
      }
    }
    for (const e of this.enemies) {
      if (!e.alive) continue;
      this.drawEnemy(c, e);
      if (e.maxHp >= 40 && !isBossKind(e.kind)) {
        c.fillStyle = "#1a1a1a";
        c.fillRect(e.x - 22, e.y - e.r - 10, 44, 4);
        c.fillStyle = "#ff3b4a";
        c.fillRect(e.x - 22, e.y - e.r - 10, 44 * (e.hp / e.maxHp), 4);
      }
    }
    for (const b of this.eBullets) {
      if (!b.alive) continue;
      const waiting = b.wait > 0;
      const rr = waiting ? b.r + 1.4 + Math.sin(b.wait * 14) * 0.9 : b.r + 0.6;
      c.fillStyle = b.color;
      c.beginPath();
      c.arc(b.x, b.y, rr, 0, Math.PI * 2);
      c.fill();
      if (waiting) {
        c.strokeStyle = "#fff4c2";
        c.lineWidth = 1;
        c.globalAlpha = 0.7;
        c.beginPath();
        c.arc(b.x, b.y, rr + 2.4, 0, Math.PI * 2);
        c.stroke();
        c.globalAlpha = 1;
      }
      c.fillStyle = "#fff";
      c.beginPath();
      c.arc(b.x, b.y, b.r * 0.45, 0, Math.PI * 2);
      c.fill();
    }
    for (const b of this.pBullets) {
      if (!b.alive) continue;
      c.fillStyle = b.color;
      c.fillRect(b.x - 1.4, b.y - 5, 2.8, 8);
    }
    for (const d of this.drones) {
      c.fillStyle = this.mode === "lance" ? "#5cff9a" : "#ffd36a";
      c.beginPath();
      c.arc(d.x, d.y, 5, 0, Math.PI * 2);
      c.fill();
      c.strokeStyle = "#fff";
      c.lineWidth = 0.8;
      c.stroke();
    }
    if (this.invuln <= 0 || Math.floor(this.invuln * 12) % 2 === 0) this.drawCraft(c, this.px, this.py, this.ship);
    if (this.vs || this.hasWing()) {
      if (this.p2invuln <= 0 || Math.floor(this.p2invuln * 12) % 2 === 0) {
        this.drawCraft(c, this.cx, this.cy, this.vs ? this.cpuShip : this.p2Ship);
      }
      c.fillStyle = this.vs ? "#f0c14a" : this.crew === "duo" ? "#3ec8ff" : "#f0c14a";
      c.font = "bold 8px monospace";
      c.textAlign = "center";
      c.fillText(this.vs ? "CPU" : this.crew === "duo" ? "P2" : "CPU", this.cx, this.cy - 22);
    }
    c.fillStyle = "#fff";
    c.beginPath();
    c.arc(this.px, this.py, this.hitR, 0, Math.PI * 2);
    c.fill();
    for (const s of this.sparks) {
      if (!s.alive) continue;
      c.globalAlpha = Math.max(0, s.life * 2);
      c.fillStyle = s.color;
      c.fillRect(s.x, s.y, s.s, s.s);
      c.globalAlpha = 1;
    }

    if ((this.bossWarn || this.midSpawnT > 0) && !this.enemies.some((e) => e.alive && isBossKind(e.kind)) && this.stageClearT <= 0) {
      const flash = Math.floor(this.stageT * 7) % 2 === 0;
      c.textAlign = "center";
      c.fillStyle = flash ? "#ff3b4a" : "#f0c14a";
      c.font = "bold 26px sans-serif";
      c.fillText("WARNING", GW / 2, GH * 0.42);
      c.fillStyle = "#e8eef8";
      c.font = "bold 12px monospace";
      c.fillText(this.incomingSpec()?.name ?? "BOSS", GW / 2, GH * 0.42 + 22);
      c.fillStyle = "#f0c14a";
      c.font = "9px monospace";
      const weak = this.incomingSpec()?.weak ?? "";
      if (weak) c.fillText(weak, GW / 2, GH * 0.42 + 38);
    }
    if (this.stageClearT > 0) {
      c.textAlign = "center";
      c.fillStyle = "#3ec8ff";
      c.font = "bold 22px sans-serif";
      c.fillText("STAGE CLEAR", GW / 2, GH * 0.42);
    }
    const boss = this.enemies.find((e) => e.alive && isBossKind(e.kind));
    if (boss && boss.t < 2.8) {
      const spec = boss.kind === "krakenkeel" ? SUB_BOSS : BOSS_META[this.stage];
      c.textAlign = "center";
      c.fillStyle = "#f0c14a";
      c.font = "9px monospace";
      c.globalAlpha = Math.min(1, 2.8 - boss.t);
      c.fillText(spec?.weak ?? "", GW / 2, 58);
      c.globalAlpha = 1;
    }
    if (this.phaseBanner > 0) {
      const a = Math.min(1, this.phaseBanner);
      c.textAlign = "center";
      c.globalAlpha = a;
      c.fillStyle = "#fff4c2";
      c.font = "bold 22px sans-serif";
      c.fillText("PHASE BREAK", GW / 2, GH * 0.36);
      c.fillStyle = "#3ec8ff";
      c.font = "bold 14px monospace";
      const ph = boss ? boss.phase + 1 : 2;
      c.fillText(`PHASE ${ph} / 3`, GW / 2, GH * 0.36 + 22);
      const sig = boss ? this.bossPhaseName(boss.kind, boss.phase) : "";
      if (sig) {
        c.fillStyle = "#f0c14a";
        c.font = "bold 11px monospace";
        c.fillText(sig, GW / 2, GH * 0.36 + 40);
      }
      c.globalAlpha = 1;
    }
    if (boss && this.bossAtk && this.phaseBanner <= 0) {
      c.textAlign = "center";
      c.fillStyle = boss.tell > 0 ? "#f0c14a" : "#e8eef8";
      c.font = "bold 10px monospace";
      c.globalAlpha = boss.tell > 0 ? 0.95 : 0.72;
      c.fillText(this.bossAtk, GW / 2, 72);
      c.globalAlpha = 1;
    }
  }

  drawCraft(c: CanvasRenderingContext2D, x: number, y: number, ship: ShipId) {
    const im = this.sprites[ship];
    if (im && im.complete && im.naturalWidth > 0) {
      const h = 36;
      const w = (im.naturalWidth / im.naturalHeight) * h;
      c.drawImage(im, x - w / 2, y - h / 2, w, h);
      return;
    }
    c.save();
    c.translate(x, y);
    c.fillStyle = ship === "azure" ? "#3ec8ff" : ship === "crimson" ? "#ff3b4a" : "#c4d46a";
    c.beginPath();
    c.moveTo(0, -16);
    c.lineTo(10, 12);
    c.lineTo(0, 6);
    c.lineTo(-10, 12);
    c.closePath();
    c.fill();
    c.fillStyle = "#e8eef8";
    c.fillRect(-2, -6, 4, 8);
    c.restore();
  }

  drawPlayer(c: CanvasRenderingContext2D) {
    this.drawCraft(c, this.px, this.py, this.ship);
  }

  drawEnemy(c: CanvasRenderingContext2D, e: Ent) {
    const stealth = e.kind === "phantomwing" && e.tag <= 0 && e.flash <= 0;
    const ghost = e.kind === "phantomwing" && !stealth;
    c.save();
    if (stealth) c.globalAlpha = 0.16;
    else if (ghost) c.globalAlpha = 0.96;
    const im = this.sprites[e.kind];
    if (im && im.complete && im.naturalWidth > 0) {
      c.save();
      c.translate(e.x, e.y);
      if (e.kind === "gyre" || e.kind === "arsenalgate") c.rotate(e.t * 0.9);
      if (e.kind === "crowncore" || e.kind === "skycathedral") c.rotate(e.t * 0.35);
      const h = e.r * (isBossKind(e.kind) ? 2.35 : 2.2);
      const w = (im.naturalWidth / im.naturalHeight) * h;
      c.drawImage(im, -w / 2, -h / 2, w, h);
      c.restore();
    } else {
      c.save();
      c.translate(e.x, e.y);
      const col: Record<string, string> = {
        wasp: "#ff9a3c",
        hornet: "#ff7a2a",
        gunbarge: "#3d6cff",
        gilded: "#f0c14a",
        eyepod: "#3ec8ff",
        redtide: "#ff3b4a",
        lancejet: "#6aa4ff",
        keel: "#3d9a9a",
        strider: "#b06cff",
        aegis: "#cfd8e6",
        core: "#f0c14a",
        mine: "#e8c84a",
        spinner: "#ff3b4a",
        gyre: "#cfd8e6",
        redmaw: "#ff3b4a",
        solarmoth: "#f0c14a",
        harborking: "#6aa4ff",
        crowncore: "#3ec8ff",
        siegcrawler: "#7cb86a",
        phantomwing: "#8aa0b8",
        rootcitadel: "#4a8a32",
        dunehauler: "#ff3b4a",
        skypike: "#cfd8e6",
        silohydra: "#e8c84a",
        ironalbatross: "#8aa0b8",
        krakenkeel: "#3d9a9a",
        battlekeel: "#6aa4ff",
        arsenalgate: "#cfd8e6",
        skycathedral: "#3ec8ff",
      };
      c.fillStyle = col[e.kind] || "#fff";
      if (e.kind === "gyre" || e.kind === "crowncore" || e.kind === "aegis" || e.kind === "eyepod" || e.kind === "arsenalgate" || e.kind === "skycathedral" || e.kind === "rootcitadel") {
        c.rotate(e.kind === "gyre" || e.kind === "arsenalgate" ? e.t : 0);
        c.beginPath();
        c.arc(0, 0, e.r, 0, Math.PI * 2);
        c.fill();
        c.fillStyle = "#070b14";
        c.beginPath();
        c.arc(0, 0, e.r * 0.4, 0, Math.PI * 2);
        c.fill();
      } else if (e.kind === "harborking" || e.kind === "battlekeel" || e.kind === "krakenkeel") {
        c.fillRect(-e.r * 0.35, -e.r, e.r * 0.7, e.r * 2);
      } else if (e.kind === "strider" || e.kind === "siegecrawler") {
        c.fillRect(-e.r * 0.5, -e.r, e.r, e.r * 1.6);
        c.fillRect(-e.r, e.r * 0.2, e.r * 0.45, e.r * 0.8);
        c.fillRect(e.r * 0.55, e.r * 0.2, e.r * 0.45, e.r * 0.8);
      } else {
        c.beginPath();
        c.moveTo(0, e.r);
        c.lineTo(e.r * 0.8, -e.r * 0.7);
        c.lineTo(0, -e.r * 0.3);
        c.lineTo(-e.r * 0.8, -e.r * 0.7);
        c.closePath();
        c.fill();
      }
      c.restore();
    }
    c.restore();
    if (ghost) {
      c.save();
      c.strokeStyle = "#cfd8e6";
      c.lineWidth = 1.6;
      c.globalAlpha = 0.85;
      c.beginPath();
      c.arc(e.x, e.y, e.r * 1.05, 0, Math.PI * 2);
      c.stroke();
      c.restore();
    }
    if (e.flash > 0) {
      c.globalAlpha = Math.min(0.85, e.flash * 8);
      c.fillStyle = "#fff";
      c.beginPath();
      c.arc(e.x, e.y, e.r * 0.85, 0, Math.PI * 2);
      c.fill();
      c.globalAlpha = 1;
    }
    if (isBossKind(e.kind)) this.drawBossTells(c, e);
  }

  drawBossTells(c: CanvasRenderingContext2D, e: Ent) {
    c.save();
    c.lineWidth = 1.6;
    if (e.kind === "siegecrawler") {
      c.fillStyle = "#f0c14a";
      c.beginPath();
      c.arc(e.x, e.y - e.r * 0.72, 4.2, 0, Math.PI * 2);
      c.fill();
      if (e.atk > 0.05) {
        c.strokeStyle = "#f0c14a";
        c.globalAlpha = 0.45 + (e.tell > 0 ? 0.35 : 0);
        c.setLineDash([4, 5]);
        c.beginPath();
        c.moveTo(e.x, e.y - 16);
        c.lineTo(e.x + Math.cos(e.atk) * 220, e.y - 16 + Math.sin(e.atk) * 220);
        c.stroke();
        c.setLineDash([]);
      }
    } else if (e.kind === "phantomwing") {
      if (e.tell > 0 || this.bossAtk === "GHOST GUNS") {
        c.strokeStyle = "#cfd8e6";
        c.globalAlpha = 0.35 + e.tell * 0.8;
        c.beginPath();
        c.arc(e.x - 34, e.y + 6, 10, 0, Math.PI * 2);
        c.arc(e.x + 34, e.y + 6, 10, 0, Math.PI * 2);
        c.stroke();
      }
    } else if (e.kind === "rootcitadel") {
      c.fillStyle = "#f0c14a";
      c.fillRect(e.x - 10, e.y - e.r * 0.78, 6, 5);
      c.fillRect(e.x + 4, e.y - e.r * 0.78, 6, 5);
      if (e.tell > 0) {
        c.strokeStyle = "#f0c14a";
        c.globalAlpha = 0.4;
        c.setLineDash([3, 4]);
        for (const ox of [-26, 0, 26]) {
          c.beginPath();
          c.moveTo(e.x + ox, e.y - 16);
          c.lineTo(e.x + ox, GH - 48);
          c.stroke();
        }
        c.setLineDash([]);
      }
    } else if (e.kind === "dunehauler" || e.kind === "redmaw") {
      c.fillStyle = "#f0c14a";
      c.fillRect(e.x - e.r - 2, e.y + 4, 8, 10);
      c.fillRect(e.x + e.r - 6, e.y + 4, 8, 10);
      if (e.tag > 0.5) {
        const dir = e.vx >= 0 ? 1 : -1;
        c.fillStyle = "#ff7a90";
        c.globalAlpha = 0.7;
        c.beginPath();
        c.moveTo(e.x + dir * (e.r + 6), e.y);
        c.lineTo(e.x + dir * (e.r + 18), e.y + 8);
        c.lineTo(e.x + dir * (e.r + 6), e.y + 16);
        c.closePath();
        c.fill();
      }
    } else if (e.kind === "skypike") {
      if (e.tag > 0.5) {
        c.fillStyle = "#ffae42";
        c.globalAlpha = 0.85;
        c.beginPath();
        c.ellipse(e.x, e.y + e.r * 0.55, 10, 5, 0, 0, Math.PI * 2);
        c.fill();
      }
      if (e.tell > 0) {
        c.strokeStyle = "#ffae42";
        c.globalAlpha = 0.3 + 0.5 * Math.sin(e.t * 18);
        c.lineWidth = 2;
        c.setLineDash([5, 6]);
        c.beginPath();
        c.moveTo(e.x, e.y + e.r * 0.5);
        c.lineTo(e.x, GH - 36);
        c.stroke();
        c.setLineDash([]);
      }
    } else if (e.kind === "silohydra") {
      const want = Math.floor(e.tag) % 3;
      const ox = (want - 1) * 16;
      c.strokeStyle = "#f0c14a";
      c.beginPath();
      c.arc(e.x + ox, e.y + 6, 6, 0, Math.PI * 2);
      c.stroke();
    } else if (e.kind === "ironalbatross") {
      c.fillStyle = "#f0c14a";
      c.beginPath();
      c.arc(e.x - 18, e.y + 4, 3.4, 0, Math.PI * 2);
      c.arc(e.x + 18, e.y + 4, 3.4, 0, Math.PI * 2);
      c.fill();
      if (e.tell > 0) {
        c.fillStyle = "#cfd8e6";
        c.globalAlpha = 0.45;
        c.fillRect(e.x - 28, e.y + 10, 56, 6);
      }
    } else if (e.kind === "krakenkeel") {
      c.fillStyle = "#f0c14a";
      if (e.phase === 0) {
        c.fillRect(e.x - 2, e.y - e.r - 6, 4, 10);
      } else {
        c.fillRect(e.x - 6, e.y + 6, 12, 5);
      }
      if (e.tell > 0 && e.phase >= 1) {
        c.strokeStyle = "#5ec8c8";
        c.globalAlpha = 0.4;
        c.beginPath();
        c.arc(e.x - 20, e.y + 8, 18, 0.2, 1.4);
        c.stroke();
        c.beginPath();
        c.arc(e.x + 20, e.y + 8, 18, 1.7, 2.9);
        c.stroke();
      }
    } else if (e.kind === "battlekeel" || e.kind === "harborking") {
      c.fillStyle = "#f0c14a";
      c.fillRect(e.x - 7, e.y + 6, 14, 5);
      if (e.tell > 0) {
        c.strokeStyle = "#6aa4ff";
        c.globalAlpha = 0.4;
        c.beginPath();
        c.moveTo(e.x - 22, e.y + 6);
        c.lineTo(e.x - 70, e.y + 90);
        c.moveTo(e.x + 22, e.y + 6);
        c.lineTo(e.x + 70, e.y + 90);
        c.stroke();
      }
    } else if (e.kind === "arsenalgate" || e.kind === "gyre") {
      c.fillStyle = "#f0c14a";
      c.beginPath();
      c.arc(e.x - e.r * 0.7, e.y, 3.6, 0, Math.PI * 2);
      c.arc(e.x + e.r * 0.7, e.y, 3.6, 0, Math.PI * 2);
      c.fill();
      if (e.atk > 0.05) {
        c.strokeStyle = "#9ad8ff";
        c.globalAlpha = 0.4;
        c.setLineDash([4, 5]);
        c.beginPath();
        c.moveTo(e.x - 26, e.y);
        c.lineTo(e.x - 26 + Math.cos(e.atk) * 180, e.y + Math.sin(e.atk) * 180);
        c.moveTo(e.x + 26, e.y);
        const a2 = Math.PI - e.atk;
        c.lineTo(e.x + 26 + Math.cos(a2) * 180, e.y + Math.sin(a2) * 180);
        c.stroke();
        c.setLineDash([]);
      }
    } else if ((e.kind === "skycathedral" || e.kind === "crowncore") && e.phase < 2) {
      const spin = e.t * (e.phase === 0 ? 1.05 : 1.45);
      const gap = e.phase === 0 ? 0.62 : 0.46;
      const rad = e.r * 1.28;
      c.strokeStyle = "#3ec8ff";
      c.lineWidth = 3.2;
      c.globalAlpha = 0.82;
      c.beginPath();
      c.arc(e.x, e.y, rad, spin + gap, spin + Math.PI * 2 - gap);
      c.stroke();
      c.strokeStyle = "#f0c14a";
      c.lineWidth = 2.4;
      c.globalAlpha = 0.95;
      c.beginPath();
      c.arc(e.x, e.y, rad, spin - gap, spin + gap);
      c.stroke();
    }
    c.restore();
  }
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
    };
    __vfDebug?: {
      skipToBoss: (stage?: number) => void;
      killBoss: () => void;
      hurtBoss?: (n?: number) => void;
      grantBounty: () => void;
      forceOver: () => void;
      forceContinue: () => void;
      startDemo: () => void;
      abortDemo: () => void;
      startHack: () => void;
      stopHack?: () => void;
    };
  }
}
